# Mazoghi Money — personal finance (Android, offline)

Package: com.mazoghi.money · WebView hybrid · LYD default · Arabic RTL + English

## Getting the APK (pick one)
**A. No installation - build in the cloud (works from a phone browser).**
1. Create a free GitHub account and a new empty repository; upload the *contents* of this folder to it (so `.github/workflows/build-apk.yml` sits at the repository root).
2. Open the repository's **Actions** tab -> **Build APK** -> **Run workflow**.
3. When it finishes (about 5-8 minutes) open the run and download **MazoghiMoney-debug-apk** from *Artifacts*; unzip it to get `app-debug.apk`.
- Optional secret `DEBUG_KEYSTORE_BASE64` (your old `debug.keystore`, base64) lets the APK install over the old app. Optional secrets `RELEASE_KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` also produce a signed release APK.

**B. Android Studio (PC).** Open this folder, wait for Gradle sync, then *Build > Build APK(s)*. The APK is in `app/build/outputs/apk/debug/`. Using the same PC/profile that built the original app keeps the same debug key.

**C. Command line.** `tools/build-apk.sh` (Linux/macOS) or `tools\build-apk.bat` (Windows) - needs the Android SDK and Gradle 8.5+. Writes `MazoghiMoney-debug.apk`.

Note: these build paths were prepared and syntax-checked but could not be executed in the environment that produced this project (no Android SDK/network there).

## Build
Open in Android Studio (AGP 8.2.2, JDK 17) → Run, or `gradle assembleDebug`.
Tests: `node --test tests/*.test.js` and `python3 tests/ui_test.py && python3 tests/ui_phase3.py && python3 tests/ui_phase4.py && python3 tests/ui_phase5.py` (needs Playwright, openpyxl, pdftotext)
Java check without the SDK: `tools/compile-check.sh`

## Phases
1. [done] Audit, project skeleton, tested finance engine, legacy-data migration, backup/restore
2. [done] UI rebuild: bundled fonts/icons/charts (no CDN), accounts, income/expense, transfers, history, RTL/EN
3. [done] Debts, budgets, savings goals, reminders + in-app alerts
4. [done] Reports, Excel export (built-in writer) and PDF (via Android print → Save as PDF), backup files with optional AES-GCM password, fingerprint + PIN, local notifications
5. [done] Hardening (limits, PIN lock-out, auto-lock, screenshot block, snapshot recovery, paging), release signing, cloud-sync contract, contrast/bidi polish

## Notes
- Data is stored by the native `NativeStore` (private file, atomic write + fsync); a read error stops the app instead of starting empty. Plain browsers fall back to localStorage.
- Existing WebView data (`myFinanceData`, `mm_state_v2`) is copied into the native store on first launch and never deleted.
- The original single-page UI is preserved untouched at assets/legacy/index.original.html (needs internet for its CDNs; no longer loaded).
- Data key `myFinanceData` is never modified or deleted; the engine copies it into `mm_state_v2`.
- Updating over the installed app requires the same signing key as the installed APK.
- Native features (files, print, fingerprint, notifications) live in `NativeBridge`/`Notifier`; the web UI falls back to browser behaviour when they are absent, which is how they are tested here. They still need a real-device test.
- Notifications use inexact alarms (no special permission); Android 13+ asks for the notification permission when the first alert is scheduled.
- The in-app `ask`/`toast` replace alert/confirm, which WebView does not display.

## Release build and signing
1. `tools/make-keystore.sh` creates `mazoghi-release.jks` and `keystore.properties` (both git-ignored). **Back them up**: without them you can never ship an update that installs over the app.
2. `gradle assembleRelease` → signed, R8-minified APK. `app/proguard-rules.pro` keeps the `NativeStore`/`NativeBridge` JavaScript interfaces.

## Upgrading from the original app (important)
Android only updates in place when the new APK has the **same signing key** as the installed one.
- The original `app-debug.apk` is debug-signed. Build this project with the **same debug keystore** (same machine/Android Studio profile) and install over it: your data (`myFinanceData`) migrates automatically.
- To move to the release key: first install the debug-signed build above, open the app once (migration), export an (optionally encrypted) backup file, uninstall, install the release APK, restore the backup.

## Cloud sync (future, optional)
`js/sync.js` defines the contract; no provider is bundled and nothing is sent anywhere today. A provider implements `pull()` and `push(blob, expectedVersion)` (throwing `CONFLICT` if the remote changed). Data is encrypted on the device with the sync password before it leaves, conflicts are reported (never silently overwritten) and resolved by the user, and a safety snapshot is kept before any remote data is applied. `memoryProvider()` is the reference implementation used by the tests.

## Safety nets
- Daily automatic snapshot; if the main data file is unreadable the app restores the snapshot (up to a day of entries can be lost) and keeps the damaged file as `mm_corrupt`. If it cannot recover it shows an error and writes nothing.
- A marker prevents a missing data file from ever being replaced by an empty database.
- PIN: 5 wrong attempts lock for 30 s, doubling up to 1 h; the lock survives restarts. The app re-locks after 30 s in the background. Screenshots/recents thumbnails are blocked (toggle in Settings).
- Amounts are capped (1e13 minor units), text fields are length-limited, audit log keeps the latest 5000 entries.
