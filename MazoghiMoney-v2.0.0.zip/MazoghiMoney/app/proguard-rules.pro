# The page calls these through window.NativeStore / window.NativeBridge; R8 must not rename or strip them.
-keepattributes JavascriptInterface
-keepclassmembers class com.mazoghi.money.NativeStore { @android.webkit.JavascriptInterface <methods>; }
-keepclassmembers class com.mazoghi.money.NativeBridge { @android.webkit.JavascriptInterface <methods>; }
-keep class com.mazoghi.money.ReminderReceiver
-keep class com.mazoghi.money.BootReceiver
