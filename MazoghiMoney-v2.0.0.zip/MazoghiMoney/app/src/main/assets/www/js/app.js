(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  const ls = { get: k => { try { return localStorage.getItem(k); } catch (e) { return null; } }, set: (k, v) => localStorage.setItem(k, v) };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const IC = { home: 'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z', hist: 'M4 5h16M4 12h16M4 19h10', acc: 'M3 7h18v12H3zM3 7l3-3h12l3 3M16 13h2', set: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19 12l2-1-1-3-2 .5-1.5-1.5.5-2-3-1-1 2h-2l-1-2-3 1 .5 2L6.5 8.5 4.5 8l-1 3 2 1v0l-2 1 1 3 2-.5L8 17.5l-.5 2 3 1 1-2h2l1 2 3-1-.5-2 1.5-1.5 2 .5 1-3z', plus: 'M12 5v14M5 12h14', plan: 'M5 4h14v16H5zM9 9h6M9 13h6M9 17h3', lock: 'M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3' };
  const pc = v => `<bdi dir="ltr">${v}%</bdi>`;   // keeps the % sign next to its digits inside Arabic text
  const ico = d => `<svg class="i" viewBox="0 0 24 24"><path d="${d}"/></svg>`;

  function makeStore() {
    const ns = window.NativeStore;
    if (!ns) return ls;                                   // plain browser: fall back to localStorage
    const get = k => { const v = ns.get(k); if (v === '__READ_ERROR__') throw new Error('read failed'); return v == null ? null : v; };
    const set = (k, v) => { if (!ns.set(k, v)) throw new Error('write failed'); };
    [MM.KEY, MM.LEGACY_KEY].forEach(k => { if (get(k) === null) { const v = ls.get(k); if (v !== null) set(k, v); } });   // one-time import from the WebView storage used by earlier versions
    return { get, set };
  }

  const PAGE = 100; let histLimit = PAGE;
  let M, S, lang = 'ar', view = 'home', filt = { type: 'all', date: 'all' };
  const t = k => (I18N[lang] || I18N.ar)[k] || k;
  const base = () => S.state.settings.baseCurrency;
  const cname = c => MM.CURRENCIES[c][lang === 'en' ? 'en' : 'ar'];
  const fmt = (m, c) => MM.format(m, c, lang);
  const catName = id => { const c = S.state.categories.find(x => x.id === id); return c ? c[lang === 'en' ? 'en' : 'ar'] : ''; };
  const accName = id => { const a = S.state.accounts.find(x => x.id === id); return a ? a.name : '?'; };
  const active = () => S.state.accounts.filter(a => !a.archived);
  /* WebView shows no alert()/confirm() without a native chrome client, so dialogs are built in-app. */
  let toastTimer;
  const toast = m => {
    let el = $('#toast'); if (!el) { el = document.createElement('div'); el.id = 'toast'; el.setAttribute('role', 'status'); document.body.appendChild(el); }
    el.textContent = m; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3500);
  };
  function dialog(html, wire) {
    return new Promise(res => {
      const el = document.createElement('div'); el.className = 'sheet'; el.id = 'ask'; el.style.zIndex = 40; el.innerHTML = '<div>' + html + '</div>'; document.body.appendChild(el);
      const done = v => { el.remove(); res(v); }; wire(el, done);
    });
  }
  const ask = (msg, yes) => dialog(`<p style="margin-bottom:14px">${esc(msg)}</p><div class="grid2"><button class="btn red" id="ask-yes">${esc(yes || t('del'))}</button><button class="btn ghost" id="ask-no">${t('cancel')}</button></div>`,
    (el, done) => { el.querySelector('#ask-yes').onclick = () => done(true); el.querySelector('#ask-no').onclick = () => done(false); });
  const askText = (msg, type) => dialog(`<label>${esc(msg)}</label><input id="ask-in" type="${type || 'password'}" autocomplete="off"><div class="grid2"><button class="btn gold" id="ask-ok">${t('save')}</button><button class="btn ghost" id="ask-no">${t('cancel')}</button></div>`,
    (el, done) => { el.querySelector('#ask-ok').onclick = () => done(el.querySelector('#ask-in').value); el.querySelector('#ask-no').onclick = () => done(null); el.querySelector('#ask-in').focus(); });

  function applySettings() {
    const st = S.state.settings; lang = st.lang || 'ar';
    document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.body.dataset.theme = st.theme || 'dark';
  }

  function inRange(ts) {
    const d = new Date(ts), n = new Date();
    if (filt.date === 'today') return d.toDateString() === n.toDateString();
    if (filt.date === 'week') return d >= new Date(n.getTime() - 7 * 864e5);
    if (filt.date === 'month') return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear();
    if (filt.date === 'year') return d.getFullYear() === n.getFullYear();
    return true;
  }
  const txLabel = x => x.type === 'transfer' ? `${t('transfer')}: ${esc(accName(x.accountId))} → ${esc(accName(x.toAccountId))}` : esc(x.title || catName(x.categoryId) || t(x.type));
  const sign = x => x.type === 'income' ? '+' : x.type === 'expense' ? '-' : '';
  const cls = x => x.type === 'income' ? 'inc' : x.type === 'expense' ? 'exp' : '';
  const dateStr = ts => new Date(ts).toLocaleDateString(lang === 'ar' ? 'ar-LY' : 'en-GB');
  function txItem(x, withDel) {
    return `<div class="item"><div><div>${txLabel(x)}</div><small>${esc(dateStr(x.ts))}${x.type !== 'transfer' ? ' · ' + esc(accName(x.accountId)) : ''}</small></div>
      <div class="row"><span class="amt ${cls(x)}">${sign(x)}${esc(fmt(x.amount, x.currency))}</span>${withDel ? `<button class="del" data-del="${esc(x.id)}">✕</button>` : ''}</div></div>`;
  }
  function donut(inc, exp) {
    const tot = inc + exp, r = 54, C = 2 * Math.PI * r, g = tot ? inc / tot * C : 0;
    return `<svg class="donut" viewBox="0 0 140 140"><circle cx="70" cy="70" r="${r}" fill="none" stroke="${tot ? 'var(--red)' : 'var(--bd)'}" stroke-width="16"/>
      ${tot ? `<circle cx="70" cy="70" r="${r}" fill="none" stroke="var(--green)" stroke-width="16" stroke-dasharray="${g} ${C}" transform="rotate(-90 70 70)"/>` : ''}</svg>
      <div class="legend"><span class="inc">● ${t('income')}</span><span class="exp">● ${t('expense')}</span></div>`;
  }

  /* ---------- views ---------- */
  function home() {
    const tot = S.totals(), list = [...S.state.transactions].reverse().slice(0, 5);
    const al = S.alerts();
    return `<h2>${t('app')}</h2>${al.length ? `<div class="card alerts"><b>${t('alerts')} (${al.length})</b>${al.slice(0, 5).map(a => `<div class="alert">${alertText(a)}</div>`).join('')}</div>` : ''}
    <div class="card hero"><small>${t('total')}</small><div class="big">${esc(fmt(S.totalBalance(), base()))}</div></div>
    <div class="grid2"><div class="card stat"><small>${t('incomes')}</small><b class="inc">${esc(fmt(tot.income, base()))}</b></div>
    <div class="card stat"><small>${t('expenses')}</small><b class="exp">${esc(fmt(tot.expense, base()))}</b></div></div>
    <div class="card">${donut(tot.income, tot.expense)}</div>
    <h3>${t('recent')}</h3><div class="card">${list.length ? list.map(x => txItem(x)).join('') : `<div class="empty">${t('none')}</div>`}</div>`;
  }
  function history() {
    const l = [...S.state.transactions].reverse().filter(x => (filt.type === 'all' || x.type === filt.type) && inRange(x.ts));
    const sum = l.reduce((s, x) => s + (x.type === 'income' ? MM.convert(x.amount, x.currency, base(), S.state.rates) : x.type === 'expense' ? -MM.convert(x.amount, x.currency, base(), S.state.rates) : 0), 0);
    const opt = (v, a, k) => `<option value="${v}" ${a === v ? 'selected' : ''}>${t(k)}</option>`;
    return `<h2>${t('history')}</h2><div class="grid2">
      <select id="f-type">${opt('all', filt.type, 'all')}${opt('income', filt.type, 'income')}${opt('expense', filt.type, 'expense')}${opt('transfer', filt.type, 'transfer')}</select>
      <select id="f-date">${['all', 'today', 'week', 'month', 'year'].map(v => opt(v, filt.date, v)).join('')}</select></div>
      <div class="card row"><span>${t('sum')}</span><b class="amt">${esc(fmt(sum, base()))}</b></div>
      <div class="card" id="hist-list">${l.length ? l.slice(0, histLimit).map(x => txItem(x, true)).join('') : `<div class="empty">${t('none')}</div>`}</div>${l.length > histLimit ? `<button class="btn ghost" id="hist-more">${t('showMore')} (${l.length - histLimit})</button>` : ''}`;
  }
  function accounts() {
    const l = S.state.accounts;
    return `<h2>${t('accounts')}</h2><div class="card">${l.map(a => `<div class="item"><div>${esc(a.name)}${a.archived ? ' · ' + t('archived') : ''}<small>${esc(cname(a.currency))}</small></div>
      <div class="row"><span class="amt">${esc(fmt(S.balance(a.id), a.currency))}</span>${a.archived ? '' : `<button class="del" data-arch="${esc(a.id)}">${t('archive')}</button>`}</div></div>`).join('') || `<div class="empty">${t('needAcc')}</div>`}</div>
      <h3>${t('newAcc')}</h3><div class="card"><label>${t('name')}</label><input id="a-name"><label>${t('currency')}</label>
      <select id="a-cur">${Object.keys(MM.CURRENCIES).map(c => `<option value="${c}" ${c === base() ? 'selected' : ''}>${c} - ${esc(cname(c))}</option>`).join('')}</select>
      <label>${t('opening')}</label><input id="a-open" type="number" inputmode="decimal" step="any" value="0"><button class="btn gold" id="a-save">${t('save')}</button></div>`;
  }
  function settings() {
    const st = S.state.settings, curs = Object.keys(MM.CURRENCIES).filter(c => c !== base());
    return `<h2>${t('settings')}</h2><div class="card"><div class="seg"><button data-lang="ar" class="${lang === 'ar' ? 'on' : ''}">العربية</button><button data-lang="en" class="${lang === 'en' ? 'on' : ''}">English</button></div>
      <div class="seg"><button data-theme="dark" class="${st.theme === 'light' ? '' : 'on'}">${t('dark')}</button><button data-theme="light" class="${st.theme === 'light' ? 'on' : ''}">${t('light')}</button></div></div>
      <div class="card"><label>${t('pin')}</label><input id="pin-new" type="password" inputmode="numeric" maxlength="4"><button class="btn gold" id="pin-save">${t('setPin')}</button>
      ${st.pinHash ? `<button class="btn ghost" id="pin-rm">${t('rmPin')}</button><button class="btn ghost" id="lock-now">${t('lockNow')}</button>` : ''}${st.pinHash && caps.biometric ? `<button class="btn ghost" id="bio-toggle">${st.biometric ? t('bioOff') : t('bioOn')}</button>` : ''}${caps.secure ? `<button class="btn ghost" id="secure-toggle">${st.secure === false ? t('secureOn') : t('secureOff')}</button>` : ''}</div>
      <h3>${t('rates')}</h3><div class="card">${curs.map(c => `<label>${c} - ${esc(cname(c))}</label><input data-rate="${c}" type="number" inputmode="decimal" step="any" value="${S.state.rates[c] || ''}">`).join('')}<button class="btn gold" id="rates-save">${t('save')}</button></div>
      <h3>${t('backup')}</h3><div class="card"><label>${t('bkPass')}</label><input id="bk-pass" type="password" autocomplete="off"><button class="btn gold" id="bk-export">${t('backupFile')}</button>
      <button class="btn ghost" id="bk-pick">${t('restoreFile')}</button><input id="bk-file" type="file" hidden><label style="margin-top:10px">${t('pasteOrFile')}</label><textarea id="bk-text" placeholder="${t('pasteBackup')}"></textarea><button class="btn ghost" id="bk-import">${t('import')}</button></div>`;
  }
  function render() {
    applySettings();
    $('#app').innerHTML = { home, history, plan, accounts, settings }[view]();
    const tabs = [['home', 'home', IC.home], ['history', 'history', IC.hist], ['add', 'add', IC.plus], ['plan', 'plan', IC.plan], ['accounts', 'accounts', IC.acc], ['settings', 'settings', IC.set]];
    const on = document.querySelector('.chips .on'); if (on && on.scrollIntoView) on.scrollIntoView({ inline: 'center', block: 'nearest' });
    $('#nav').innerHTML = tabs.map(([v, k, d]) => v === 'add' ? `<button class="plus" data-go="add" aria-label="${t('add')}">${ico(d)}</button>` : `<button data-go="${v}" class="${view === v ? 'on' : ''}">${ico(d)}<span>${t(k)}</span></button>`).join('');
  }


  /* ---------- Plan: debts / budgets / goals / reminders ---------- */
  let planTab = 'debts';
  const bar = (pct, plain) => `<div class="bar ${plain ? '' : pct >= 100 ? 'bad' : pct >= 80 ? 'warn' : ''}"><i style="width:${Math.min(100, pct)}%"></i></div>`;
  const dueTxt = iso => iso ? esc(new Date(iso.length === 10 ? iso + 'T00:00:00' : iso).toLocaleDateString(lang === 'ar' ? 'ar-LY' : 'en-GB')) : '';
  function alertText(a) {
    if (a.kind === 'reminder') return `🔔 ${esc(a.title)}`;
    if (a.kind === 'debt') return `${a.debtKind === 'owed_to_me' ? '↙' : '↗'} ${esc(a.person)} · ${a.overdue ? t('overdue') : a.days === 0 ? t('dueToday') : t('dueIn') + ' ' + a.days + ' ' + t('days')}`;
    return `${a.over ? '⛔' : '⚠️'} ${esc(catName(a.categoryId))} ${pc(a.pct)}`;
  }
  function plan() {
    const tabs = ['debts', 'budgets', 'goals', 'reminders', 'reports'];
    return `<h2>${t('plan')}</h2><div class="chips">${tabs.map(k => `<button data-plan="${k}" class="${planTab === k ? 'on' : ''}">${t(k)}</button>`).join('')}</div>` + { debts: debtsView, budgets: budgetsView, goals: goalsView, reminders: remindersView, reports: reportsView }[planTab]();
  }
  function debtsView() {
    const l = [...S.state.debts].sort((a, b) => a.closed - b.closed);
    const card = d => { const rem = S.debtRemaining(d.id), pct = Math.round((d.principal - rem) / d.principal * 100);
      return `<div class="card ${d.closed ? 'dim' : ''}"><div class="row"><b>${esc(d.person)}</b><span class="${d.kind === 'owed_to_me' ? 'inc' : 'exp'}">${t(d.kind === 'owed_to_me' ? 'owedToMe' : 'iOwe')}</span></div>
      <div class="row"><span>${t('remaining')}: <b class="amt">${esc(fmt(rem, d.currency))}</b></span><small>${t('of')} ${esc(fmt(d.principal, d.currency))}</small></div>${bar(pct)}
      <div class="row"><small>${d.dueDate ? t('due') + ': ' + dueTxt(d.dueDate) : ''}</small>${d.closed ? `<small>${t('closed')}</small>` : `<button class="mini gold" data-paydebt="${esc(d.id)}">${t('pay')}</button>`}</div></div>`; };
    return `<button class="btn gold" data-newdebt>${t('newDebt')}</button><div style="height:12px"></div>` + (l.map(card).join('') || `<div class="empty">${t('noItems')}</div>`);
  }
  function budgetsView() {
    const l = S.budgetStatus();
    return `<button class="btn gold" data-newbudget>${t('newBudget')}</button><div style="height:12px"></div>` + (l.map(b => `<div class="card"><div class="row"><b>${esc(catName(b.categoryId))}</b><button class="del" data-rmbudget="${esc(b.categoryId)}">${t('rmBudget')}</button></div>
      <div class="row"><span>${t('spent')}: <b class="amt ${b.over ? 'exp' : ''}">${esc(fmt(b.spent, base()))}</b></span><small>${t('of')} ${esc(fmt(b.limit, base()))}</small></div>${bar(b.pct)}
      <small>${b.over ? '⛔ ' + t('over') : esc(fmt(b.remaining, base())) + ' ' + t('remaining')}${b.unconverted ? ' · ' + t('needRate') : ''}</small></div>`).join('') || `<div class="empty">${t('noItems')}</div>`);
  }
  function goalsView() {
    return `<button class="btn gold" data-newgoal>${t('newGoal')}</button><div style="height:12px"></div>` + (S.state.goals.map(g => { const p = S.goalProgress(g.id);
      return `<div class="card"><div class="row"><b>${esc(g.name)}</b><span class="${p.done ? 'inc' : ''}">${pc(p.pct)}</span></div><div class="row"><span>${t('saved')}: <b class="amt">${esc(fmt(p.saved, g.currency))}</b></span><small>${t('of')} ${esc(fmt(g.target, g.currency))}</small></div>${bar(p.pct)}
      <div class="row"><small>${g.deadline ? t('deadline').replace(/ \(.*\)|\s*\(.*\)/, '') + ': ' + dueTxt(g.deadline) : ''}</small>${p.done ? '<small>✓</small>' : `<button class="mini gold" data-contrib="${esc(g.id)}">${t('contribute')}</button>`}</div></div>`; }).join('') || `<div class="empty">${t('noItems')}</div>`);
  }
  function remindersView() {
    const l = [...S.state.reminders].sort((a, b) => a.done - b.done || new Date(a.due) - new Date(b.due));
    return `<button class="btn gold" data-newrem>${t('newReminder')}</button><div style="height:12px"></div><div class="card">` + (l.map(r => `<div class="item ${r.done ? 'dim' : ''}"><div>${esc(r.title)}<small>${dueTxt(r.due)}${r.repeat !== 'none' ? ' · ' + t(r.repeat === 'weekly' ? 'rWeekly' : 'rMonthly') : ''}</small></div>${r.done ? '' : `<button class="mini gold" data-remdone="${esc(r.id)}">${t('done')}</button>`}</div>`).join('') || `<div class="empty">${t('noItems')}</div>`) + `</div>`;
  }


  /* ---------- Reports, export, files ---------- */
  let repPeriod = 'month';
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  function periodRange(p) {
    const n = new Date(), y = n.getFullYear(), m = n.getMonth();
    if (p === 'month') return { from: ymd(new Date(y, m, 1)), to: ymd(new Date(y, m + 1, 0)) };
    if (p === 'last') return { from: ymd(new Date(y, m - 1, 1)), to: ymd(new Date(y, m, 0)) };
    if (p === 'year') return { from: y + '-01-01', to: y + '-12-31' };
    return { from: null, to: null };
  }
  function trendSvg(months) {
    const max = Math.max(1, ...months.map(m => Math.max(m.income, m.expense))), n = Math.max(1, months.length), step = 300 / n, bw = Math.min(18, step / 2 - 4);
    return `<svg viewBox="0 0 320 128" style="width:100%">` + months.map((m, i) => { const x = 10 + i * step, hi = Math.round(m.income / max * 80), he = Math.round(m.expense / max * 80);
      return `<rect x="${x}" y="${100 - hi}" width="${bw}" height="${hi}" fill="var(--green)" rx="3"/><rect x="${x + bw + 3}" y="${100 - he}" width="${bw}" height="${he}" fill="var(--red)" rx="3"/><text x="${x + bw}" y="118" font-size="10" text-anchor="middle" fill="var(--tx2)">${esc(m.month.slice(5))}</text>`; }).join('') + `</svg>`;
  }
  function reportsView() {
    const rg = periodRange(repPeriod), r = S.report(rg), months = r.byMonth.slice(-6);
    const opts = [['month', 'thisMonth'], ['last', 'lastMonth'], ['year', 'thisYear'], ['all', 'allTime']];
    return `<select id="rep-period">${opts.map(([v, k]) => `<option value="${v}" ${repPeriod === v ? 'selected' : ''}>${t(k)}</option>`).join('')}</select>
      <div class="grid2"><div class="card stat"><small>${t('income')}</small><b class="inc">${esc(fmt(r.income, base()))}</b></div><div class="card stat"><small>${t('expense')}</small><b class="exp">${esc(fmt(r.expense, base()))}</b></div></div>
      <div class="card hero"><small>${t('net')}</small><div class="big" id="rep-net">${esc(fmt(r.net, base()))}</div></div>
      ${r.unconverted ? `<div class="card"><small>${t('needRate')} (${r.unconverted})</small></div>` : ''}
      <h3>${t('topCats')}</h3><div class="card" id="rep-cats">${r.byCategory.map(c => `<div class="row"><span>${esc(catName(c.categoryId) || t('other'))}</span><span class="amt">${esc(fmt(c.total, base()))} · ${pc(c.pct)}</span></div>${bar(c.pct, true)}`).join('') || `<div class="empty">${t('noItems')}</div>`}</div>
      <h3>${t('trend')}</h3><div class="card" id="rep-trend">${months.length ? trendSvg(months) : `<div class="empty">${t('noItems')}</div>`}<div class="legend"><span class="inc">● ${t('income')}</span><span class="exp">● ${t('expense')}</span></div></div>
      <h3>${t('accountsBal')}</h3><div class="card">${r.accounts.map(a => `<div class="item"><span>${esc(a.name)}</span><span class="amt">${esc(fmt(a.balance, a.currency))}</span></div>`).join('') || `<div class="empty">${t('noItems')}</div>`}</div>
      <h3>${t('debtsSum')}</h3><div class="card"><div class="item"><span>${t('owedToMe')}</span><b class="amt inc">${esc(fmt(r.debts.owedToMe, base()))}</b></div><div class="item"><span>${t('iOwe')}</span><b class="amt exp">${esc(fmt(r.debts.iOwe, base()))}</b></div></div>
      <div class="grid2"><button class="btn gold" id="rep-xlsx">${t('exportXlsx')}</button><button class="btn gold" id="rep-pdf">${t('exportPdf')}</button></div>`;
  }
  function reportHtml(rg, r, txs) {
    const row = x => `<tr><td>${esc(dateStr(x.ts))}</td><td>${esc(t(x.type))}</td><td>${esc(accName(x.accountId))}</td><td>${txLabel(x)}</td><td class="n">${sign(x)}${esc(fmt(x.amount, x.currency))}</td></tr>`;
    const kv = (k, v) => `<tr><td>${k}</td><td class="n">${esc(v)}</td></tr>`;
    return `<h1>${t('app')} — ${t('reports')}</h1><div class="meta">${t('period')}: ${esc(rg.from || '…')} → ${esc(rg.to || '…')} · ${t('generated')}: ${esc(dateStr(new Date().toISOString()))}</div>
      <h2>${t('summary')}</h2><table>${kv(t('income'), fmt(r.income, base()))}${kv(t('expense'), fmt(r.expense, base()))}${kv(t('net'), fmt(r.net, base()))}</table>
      <h2>${t('topCats')}</h2><table>${r.byCategory.map(c => kv(esc(catName(c.categoryId) || t('other')) + ' (' + pc(c.pct) + ')', fmt(c.total, base()))).join('')}</table>
      <h2>${t('accountsBal')}</h2><table>${r.accounts.map(a => kv(esc(a.name), fmt(a.balance, a.currency))).join('')}</table>
      <h2>${t('debtsSum')}</h2><table>${kv(t('owedToMe'), fmt(r.debts.owedToMe, base()))}${kv(t('iOwe'), fmt(r.debts.iOwe, base()))}</table>
      <h2>${t('tx')}</h2><table><tr><th>${t('date')}</th><th>${t('type')}</th><th>${t('account')}</th><th>${t('title')}</th><th class="n">${t('amount')}</th></tr>${txs.slice(-500).map(row).join('')}</table>`;
  }
  function printReport() {
    const rg = periodRange(repPeriod); $('#print').innerHTML = reportHtml(rg, S.report(rg), S.transactionsIn(rg));
    if (window.NativeBridge) NativeBridge.printPage('Mazoghi-Money-' + ymd(new Date())); else window.print();
  }
  const b64 = u8 => { let o = ''; for (let i = 0; i < u8.length; i += 8192) o += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(o); };
  function saveFile(name, mime, data) {
    const u8 = typeof data === 'string' ? new TextEncoder().encode(data) : data;
    if (window.NativeBridge) return NativeBridge.saveFile(name, mime, b64(u8));
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([u8], { type: mime })); a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000); toast(t('fileSaved'));
  }
  window.__onFileSaved = ok => toast(ok ? t('fileSaved') : t('fileFailed'));
  function exportXlsx() {
    const rg = periodRange(repPeriod), txs = S.transactionsIn(rg), r = S.report(rg), rtl = lang === 'ar';
    const dstr = ts => { const d = new Date(ts); return ymd(d) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); };
    const amt = (v, c) => ({ v: MM.fromMinor(v, c), d: MM.CURRENCIES[c].dec === 3 ? 3 : 2 });
    const signed = x => x.type === 'income' ? x.amount : -x.amount;   // income +, expense and outgoing transfer −
    const sheets = [
      { name: t('summary'), rtl, widths: [26, 20], rows: [[t('period'), rg.from || '…', ], [t('income') + ' (' + base() + ')', amt(r.income, base())], [t('expense') + ' (' + base() + ')', amt(r.expense, base())], [t('net') + ' (' + base() + ')', amt(r.net, base())], [t('owedToMe') + ' (' + base() + ')', amt(r.debts.owedToMe, base())], [t('iOwe') + ' (' + base() + ')', amt(r.debts.iOwe, base())]] },
      { name: t('tx'), rtl, widths: [18, 12, 18, 18, 16, 24, 16, 10, 24], rows: [[t('date'), t('type'), t('account'), t('to'), t('category'), t('title'), t('amount'), t('currency'), t('note')]].concat(txs.map(x => [dstr(x.ts), t(x.type), accName(x.accountId), x.type === 'transfer' ? accName(x.toAccountId) : '', catName(x.categoryId), x.title || '', amt(signed(x), x.currency), x.currency, x.note || ''])) },
      { name: t('accounts'), rtl, widths: [24, 10, 18, 18], rows: [[t('name'), t('currency'), t('balance'), t('opening')]].concat(S.state.accounts.map(a => [a.name + (a.archived ? ' (' + t('archived') + ')' : ''), a.currency, amt(S.balance(a.id), a.currency), amt(a.opening || 0, a.currency)])) },
      { name: t('debts'), rtl, widths: [22, 14, 10, 16, 16, 16, 14], rows: [[t('person'), t('type'), t('currency'), t('amount'), t('paid'), t('remaining'), t('due')]].concat(S.state.debts.map(d => [d.person, t(d.kind === 'owed_to_me' ? 'owedToMe' : 'iOwe'), d.currency, amt(d.principal, d.currency), amt(d.principal - S.debtRemaining(d.id), d.currency), amt(S.debtRemaining(d.id), d.currency), d.dueDate || ''])) }
    ];
    saveFile('mazoghi-report-' + ymd(new Date()) + '.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', MMX.build(sheets));
  }

  /* ---------- Backup files ---------- */
  async function exportBackupFile() {
    const pw = $('#bk-pass').value; let json = S.exportBackup();
    if (pw) json = await MM.encryptBackup(json, pw);
    saveFile('mazoghi-backup-' + ymd(new Date()) + (pw ? '.enc' : '') + '.json', 'application/json', json);
  }
  async function handleBackupText(text) {
    try {
      if (MM.isEncryptedBackup(text)) { const pw = await askText(t('enterBackupPw')); if (pw === null) return; text = await MM.decryptBackup(text, pw); }
      JSON.parse(text);
      if (!(await ask(t('confirmRestore'), t('import')))) return;
      S.importBackup(text); toast(t('restored')); render(); syncNotifications();
    } catch (e) { toast(/password/i.test(e.message) ? t('wrongBackupPw') : t('bad')); }
  }
  window.__onFilePicked = text => { if (text) handleBackupText(text); };

  /* ---------- Native extras: fingerprint, notifications ---------- */
  const caps = (() => { try { return window.NativeBridge ? JSON.parse(NativeBridge.capabilities()) : {}; } catch (e) { return {}; } })();
  let bioMode = null;
  const startBio = mode => { bioMode = mode; NativeBridge.authenticate(t('bioPrompt'), t('cancel')); };
  window.__onBiometric = ok => {
    const mode = bioMode; bioMode = null;
    if (!ok) return;
    if (mode === 'enable') { S.state.settings.biometric = true; S.save(); toast(t('bioEnabled')); render(); }
    else unlock();
  };
  const applySecure = () => { try { if (window.NativeBridge && caps.secure) NativeBridge.setSecure(S.state.settings.secure !== false); } catch (e) { /* best effort */ } };
  function syncNotifications() {
    if (!window.NativeBridge) return;
    try { NativeBridge.scheduleNotifications(JSON.stringify(S.notificationPlan().map(p => ({ key: p.key, at: p.at, title: p.kind === 'reminder' ? p.title : t('debtDueNotif') + ': ' + p.person })))); } catch (e) { /* alerts are best-effort */ }
  }

  /* generic bottom-sheet form: fields = [{id,label,type,options:[[value,label]],value,step}] */
  function openForm(fields, onSave) {
    $('#sheet').hidden = false;
    $('#sheet').innerHTML = `<div>${fields.map(f => `<label>${esc(f.label)}</label>` + (f.options ? `<select id="f_${f.id}">${f.options.map(([v, l]) => `<option value="${esc(v)}" ${v === f.value ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>` : `<input id="f_${f.id}" type="${f.type || 'text'}" ${f.type === 'number' ? 'inputmode="decimal" step="any"' : ''} value="${esc(f.value || '')}">`)).join('')}
      <button class="btn gold" id="form-save">${t('save')}</button><button class="btn ghost" id="s-cancel">${t('cancel')}</button></div>`;
    formSave = () => { const v = {}; fields.forEach(f => v[f.id] = $('#f_' + f.id).value); try { onSave(v); closeSheet(); render(); syncNotifications(); } catch (e) { toast(errMsg(e)); } };
  }
  let formSave = null;
  function errMsg(e) {
    const m = e.message || '';
    if (/exceeds/.test(m)) return t('exceeds'); if (/currency must match/.test(m)) return t('curMismatch'); if (/Missing rate/.test(m)) return t('needRate'); return t('invalid');
  }
  const curOpts = () => Object.keys(MM.CURRENCIES).map(c => [c, c + ' - ' + cname(c)]);
  const dateOrNull = v => v ? v : null;
  function planAction(d) {
    if ('newdebt' in d) return openForm([{ id: 'kind', label: t('debts'), options: [['owed_to_me', t('owedToMe')], ['i_owe', t('iOwe')]] }, { id: 'person', label: t('person') }, { id: 'amount', label: t('amount'), type: 'number' }, { id: 'cur', label: t('currency'), options: curOpts(), value: base() }, { id: 'due', label: t('due'), type: 'date' }],
      v => S.addDebt({ kind: v.kind, person: v.person, amount: MM.toMinor(v.amount, v.cur), currency: v.cur, dueDate: dateOrNull(v.due) }));
    if (d.paydebt) { const debt = S.state.debts.find(x => x.id === d.paydebt), accs = active().filter(a => a.currency === debt.currency);
      return openForm([{ id: 'amount', label: t('amount') + ' (' + debt.currency + ')', type: 'number' }, { id: 'acc', label: t('payFrom'), options: [['', t('noAccount')]].concat(accs.map(a => [a.id, a.name])) }],
        v => S.addDebtPayment({ debtId: debt.id, amount: MM.toMinor(v.amount, debt.currency), accountId: v.acc || null })); }
    if ('newbudget' in d) { const cats = S.state.categories.filter(c => c.kind === 'expense');
      return openForm([{ id: 'cat', label: t('category'), options: cats.map(c => [c.id, c[lang === 'en' ? 'en' : 'ar']]) }, { id: 'limit', label: t('monthlyLimit') + ' (' + base() + ')', type: 'number' }], v => S.setBudget(v.cat, MM.toMinor(v.limit, base()))); }
    if (d.rmbudget) { S.removeBudget(d.rmbudget); return render(); }
    if ('newgoal' in d) return openForm([{ id: 'name', label: t('name') }, { id: 'target', label: t('target'), type: 'number' }, { id: 'cur', label: t('currency'), options: curOpts(), value: base() }, { id: 'dl', label: t('deadline'), type: 'date' }],
      v => S.addGoal({ name: v.name, target: MM.toMinor(v.target, v.cur), currency: v.cur, deadline: dateOrNull(v.dl) }));
    if (d.contrib) { const g = S.state.goals.find(x => x.id === d.contrib);
      return openForm([{ id: 'amount', label: t('amount') + ' (' + g.currency + ')', type: 'number' }], v => S.contribute(g.id, MM.toMinor(v.amount, g.currency))); }
    if ('newrem' in d) return openForm([{ id: 'title', label: t('title') }, { id: 'due', label: t('due'), type: 'datetime-local' }, { id: 'rep', label: t('repeat'), options: [['none', t('rNone')], ['weekly', t('rWeekly')], ['monthly', t('rMonthly')]] }],
      v => S.addReminder({ title: v.title, due: v.due, repeat: v.rep }));
    if (d.remdone) { S.completeReminder(d.remdone); render(); return syncNotifications(); }
  }

  /* ---------- add sheet ---------- */
  let addType = 'expense';
  function openAdd() {
    const accs = active(); if (!accs.length) { toast(t('needAcc')); view = 'accounts'; return render(); }
    const opts = accs.map(a => `<option value="${esc(a.id)}">${esc(a.name)} (${a.currency})</option>`).join('');
    const cats = S.state.categories.filter(c => c.kind === addType).map(c => `<option value="${esc(c.id)}">${esc(c[lang === 'en' ? 'en' : 'ar'])}</option>`).join('');
    const tr = addType === 'transfer';
    $('#sheet').hidden = false;
    $('#sheet').innerHTML = `<div><div class="seg">${['expense', 'income', 'transfer'].map(k => `<button data-type="${k}" class="${addType === k ? 'on' : ''}">${t(k)}</button>`).join('')}</div>
      <label>${tr ? t('from') : t('account')}</label><select id="s-acc">${opts}</select>
      ${tr ? `<label>${t('to')}</label><select id="s-to">${opts}</select>` : `<label>${t('category')}</label><select id="s-cat">${cats}</select>`}
      <label>${t('amount')}</label><input id="s-amt" type="number" inputmode="decimal" step="any">
      ${tr ? `<label>${t('received')}</label><input id="s-amt2" type="number" inputmode="decimal" step="any">` : ''}
      <label>${t('note')}</label><input id="s-note">
      <button class="btn ${addType === 'income' ? 'green' : addType === 'expense' ? 'red' : 'gold'}" id="s-save">${t('save')}</button><button class="btn ghost" id="s-cancel">${t('cancel')}</button></div>`;
    if (tr && accs.length > 1) $('#s-to').selectedIndex = 1;
  }
  const closeSheet = () => { $('#sheet').hidden = true; $('#sheet').innerHTML = ''; };
  function saveAdd() {
    try {
      const accId = $('#s-acc').value, a = S.state.accounts.find(x => x.id === accId), amt = MM.toMinor($('#s-amt').value, a.currency), note = $('#s-note').value.trim();
      if (!(amt > 0)) return toast(t('invalid'));
      if (addType === 'transfer') {
        const b = S.state.accounts.find(x => x.id === $('#s-to').value), v2 = $('#s-amt2').value;
        S.addTransfer({ fromId: accId, toId: b.id, amount: amt, toAmount: v2 ? MM.toMinor(v2, b.currency) : undefined, note });
      } else S.addTransaction({ type: addType, accountId: accId, categoryId: $('#s-cat').value, amount: amt, title: note });
      closeSheet(); view = 'home'; render();
    } catch (e) { toast(e.message === 'Missing rate for USD' || /Missing rate/.test(e.message) ? t('rates') : t('invalid')); }
  }

  /* ---------- lock ---------- */
  let hiddenAt = 0; const AUTO_LOCK_MS = 30000;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) hiddenAt = Date.now();
    else if (S && S.state.settings.pinHash && hiddenAt && Date.now() - hiddenAt > AUTO_LOCK_MS && $('#lock').hidden) showLock();   // lock again after the app was in the background
  });
  function unlock() { const el = $('#lock'); el.hidden = true; el.innerHTML = ''; }
  function showLock() {
    const el = $('#lock'); el.hidden = false; const bio = caps.biometric && S.state.settings.biometric;
    el.innerHTML = `<div class="card">${ico(IC.lock)}<h2>${t('enterPin')}</h2><input id="lk" type="password" inputmode="numeric" maxlength="4" autofocus><div class="err" id="lk-err"></div>${bio ? `<button class="btn ghost" id="bio-unlock">${t('bioUse')}</button>` : ''}</div>`;
    $('#lk').addEventListener('input', async e => {
      if (e.target.value.length < 4) return;
      const r = await MM.tryPin(e.target.value, S.state); if (r.changed) S.save(false);   // attempt counters persist across restarts
      e.target.value = '';
      if (r.ok) unlock();
      else $('#lk-err').textContent = r.waitMs > 0 ? t('tryLater').replace('{s}', Math.ceil(r.waitMs / 1000)) : t('wrongPin');
    });
    if (bio) startBio('unlock');
  }

  /* ---------- events ---------- */
  document.addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return;
    const d = b.dataset;
    if (d.plan) { planTab = d.plan; return render(); }
    if (b.id === 'hist-more') { histLimit += PAGE; return render(); }
    if (b.id === 'form-save') return formSave && formSave();
    if ('newdebt' in d || d.paydebt || 'newbudget' in d || d.rmbudget || 'newgoal' in d || d.contrib || 'newrem' in d || d.remdone) return planAction(d);
    if (d.go) { if (d.go === 'add') { addType = 'expense'; return openAdd(); } view = d.go; return render(); }
    if (d.type) { addType = d.type; return openAdd(); }
    if (b.id === 's-cancel') return closeSheet();
    if (b.id === 's-save') return saveAdd();
    if (d.del) { if (await ask(t('confirmDel'))) { S.deleteTransaction(d.del); render(); } return; }
    if (d.arch) { S.archiveAccount(d.arch); return render(); }
    if (d.lang) { S.state.settings.lang = d.lang; S.save(); return render(); }
    if (d.theme) { S.state.settings.theme = d.theme; S.save(); return render(); }
    if (b.id === 'a-save') {
      try { const c = $('#a-cur').value; S.addAccount({ name: $('#a-name').value, currency: c, opening: MM.toMinor($('#a-open').value || 0, c) }); render(); } catch (er) { toast(t('invalid')); } return;
    }
    if (b.id === 'pin-save') {
      const v = $('#pin-new').value; if (!/^\d{4}$/.test(v)) return toast(t('pinErr'));
      const h = await MM.hashPin(v); S.state.settings.pinHash = h.hash; S.state.settings.pinSalt = h.salt; S.save(); toast(t('saved')); return render();
    }
    if (b.id === 'pin-rm') { S.state.settings.pinHash = null; S.state.settings.pinSalt = null; S.state.settings.biometric = false; S.save(); return render(); }
    if (b.id === 'lock-now') return showLock();
    if (b.id === 'rates-save') { document.querySelectorAll('[data-rate]').forEach(i => { const v = parseFloat(i.value); if (v > 0 && v !== S.state.rates[i.dataset.rate]) S.setRate(i.dataset.rate, v); }); toast(t('saved')); return render(); }
    if (b.id === 'bk-export') return exportBackupFile();
    if (b.id === 'bk-pick') return window.NativeBridge ? NativeBridge.pickFile() : $('#bk-file').click();
    if (b.id === 'bk-import') return handleBackupText($('#bk-text').value);
    if (b.id === 'rep-xlsx') return exportXlsx();
    if (b.id === 'rep-pdf') return printReport();
    if (b.id === 'bio-toggle') { if (S.state.settings.biometric) { S.state.settings.biometric = false; S.save(); return render(); } return startBio('enable'); }
    if (b.id === 'bio-unlock') return startBio('unlock');
    if (b.id === 'secure-toggle') { S.state.settings.secure = S.state.settings.secure === false; S.save(false); applySecure(); return render(); }
  });
  document.addEventListener('change', e => {
    if (e.target.id === 'rep-period') { repPeriod = e.target.value; render(); }
    if (e.target.id === 'bk-file' && e.target.files[0]) { const f = e.target.files[0], rd = new FileReader(); rd.onload = () => handleBackupText(String(rd.result)); rd.readAsText(f); e.target.value = ''; }
    if (e.target.id === 'f-type') { filt.type = e.target.value; histLimit = PAGE; render(); }
    if (e.target.id === 'f-date') { filt.date = e.target.value; histLimit = PAGE; render(); }
  });

  Promise.resolve().then(() => MM.open(makeStore())).then(s => { S = s; applySettings(); render(); if (S.state.settings.pinHash) showLock(); applySecure(); syncNotifications(); if (S.recovered) toast(t('recovered')); })
    .catch(() => { document.body.innerHTML = '<p style="padding:24px;color:#ef4444">Storage error. Your data was not modified. Restart the app.</p>'; });
})();
