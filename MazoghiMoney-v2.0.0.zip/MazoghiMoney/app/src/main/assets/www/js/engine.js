/* Mazoghi Money - core engine (pure JS, offline, no dependencies).
   Money is stored as integer minor units (LYD has 3 decimals) to avoid float errors. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MM = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const MAX_MINOR = 1e13, LOG_CAP = 5000, SNAP_EVERY_MS = 864e5;
  const SCHEMA = 2, BASE = 'LYD', KEY = 'mm_state_v2', LEGACY_KEY = 'myFinanceData';

  const CURRENCIES = {
    LYD: { ar: 'دينار ليبي', en: 'Libyan Dinar', sym_ar: 'د.ل', sym_en: 'LYD', dec: 3 },
    USD: { ar: 'دولار أمريكي', en: 'US Dollar', sym_ar: '$', sym_en: 'USD', dec: 2 },
    EUR: { ar: 'يورو', en: 'Euro', sym_ar: '€', sym_en: 'EUR', dec: 2 },
    GBP: { ar: 'جنيه إسترليني', en: 'Pound Sterling', sym_ar: '£', sym_en: 'GBP', dec: 2 },
    TND: { ar: 'دينار تونسي', en: 'Tunisian Dinar', sym_ar: 'د.ت', sym_en: 'TND', dec: 3 },
    EGP: { ar: 'جنيه مصري', en: 'Egyptian Pound', sym_ar: 'ج.م', sym_en: 'EGP', dec: 2 },
    SAR: { ar: 'ريال سعودي', en: 'Saudi Riyal', sym_ar: 'ر.س', sym_en: 'SAR', dec: 2 },
    AED: { ar: 'درهم إماراتي', en: 'UAE Dirham', sym_ar: 'د.إ', sym_en: 'AED', dec: 2 },
    TRY: { ar: 'ليرة تركية', en: 'Turkish Lira', sym_ar: '₺', sym_en: 'TRY', dec: 2 }
  };
  const clean = (v, max, what) => { const x = String(v == null ? '' : v).trim(); if (x.length > max) throw new Error(what + ' too long'); return x; };
  const checkTs = ts => { if (ts && isNaN(new Date(ts))) throw new Error('Invalid date'); return ts; };
  const dec = c => { if (!CURRENCIES[c]) throw new Error('Unknown currency: ' + c); return CURRENCIES[c].dec; };
  const toMinor = (amount, cur) => Math.round(Number(amount) * Math.pow(10, dec(cur)));
  const fromMinor = (minor, cur) => minor / Math.pow(10, dec(cur));
  function format(minor, cur, lang) {
    const c = CURRENCIES[cur], neg = minor < 0, v = Math.abs(fromMinor(minor, cur)).toFixed(c.dec);
    const [i, f] = v.split('.'), g = i.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (neg ? '-' : '') + g + (f ? '.' + f : '') + ' ' + (lang === 'en' ? c.sym_en : c.sym_ar);
  }

  /* rates: { USD: 4.85 } means 1 USD = 4.85 LYD (base currency rate is always 1) */
  function convert(minor, from, to, rates) {
    if (from === to) return minor;
    const r = c => { const x = c === BASE ? 1 : rates && rates[c]; if (!(x > 0)) throw new Error('Missing rate for ' + c); return x; };
    return toMinor(fromMinor(minor, from) * r(from) / r(to), to);
  }

  let seq = 0;
  const uid = () => Date.now().toString(36) + (++seq).toString(36) + Math.random().toString(36).slice(2, 6);
  const nowIso = () => new Date().toISOString();

  const monthKey = d => { d = new Date(d); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); };
  const dayDiff = (iso, now) => Math.floor((new Date(iso + (String(iso).length === 10 ? 'T00:00:00' : '')) - new Date(now).setHours(0, 0, 0, 0)) / 864e5);
  function addPeriod(iso, repeat) { const d = new Date(iso); if (repeat === 'weekly') d.setDate(d.getDate() + 7); else d.setMonth(d.getMonth() + 1); return d.toISOString(); }

  const DEFAULT_CATEGORIES = [
    ['income', 'مرتب', 'Salary'], ['income', 'دخل يومي', 'Daily income'], ['income', 'عمل حر', 'Freelance'], ['income', 'أخرى', 'Other income'],
    ['expense', 'طعام', 'Food'], ['expense', 'مواصلات', 'Transport'], ['expense', 'فواتير', 'Bills'], ['expense', 'تسوق', 'Shopping'],
    ['expense', 'صحة', 'Health'], ['expense', 'تعليم', 'Education'], ['expense', 'ترفيه', 'Entertainment'], ['expense', 'أخرى', 'Other expenses']
  ];

  function emptyState() {
    return {
      schema: SCHEMA, createdAt: nowIso(),
      settings: { baseCurrency: BASE, lang: 'ar', theme: 'dark', pinHash: null, pinSalt: null, biometric: false },
      accounts: [], categories: DEFAULT_CATEGORIES.map(([kind, ar, en], i) => ({ id: 'cat_' + kind + '_' + i, kind, ar, en })),
      transactions: [], debts: [], budgets: [], goals: [], reminders: [], rates: {}, rateHistory: [], log: []
    };
  }

  /* ---- PIN hashing (PBKDF2-SHA256, WebCrypto) ---- */
  const hex = b => Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join('');
  async function hashPin(pin, saltHex) {
    const c = globalThis.crypto, enc = new TextEncoder();
    const salt = saltHex || hex(c.getRandomValues(new Uint8Array(16)));
    const saltBytes = new Uint8Array(salt.match(/../g).map(h => parseInt(h, 16)));
    const key = await c.subtle.importKey('raw', enc.encode(String(pin)), 'PBKDF2', false, ['deriveBits']);
    const bits = await c.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: saltBytes, iterations: 100000 }, key, 256);
    return { hash: hex(bits), salt };
  }
  async function verifyPin(pin, st) {
    if (!st.settings.pinHash) return true;
    return (await hashPin(pin, st.settings.pinSalt)).hash === st.settings.pinHash;
  }


  /* ---- Optional password encryption for backup files (AES-GCM, PBKDF2-SHA256) ---- */
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(s); };
  const unb64 = t => Uint8Array.from(atob(t), c => c.charCodeAt(0));
  async function deriveKey(password, salt) {
    const k = await globalThis.crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
    return globalThis.crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 150000 }, k, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function encryptBackup(json, password) {
    if (!password) throw new Error('Password required');
    const c = globalThis.crypto, salt = c.getRandomValues(new Uint8Array(16)), iv = c.getRandomValues(new Uint8Array(12));
    const ct = await c.subtle.encrypt({ name: 'AES-GCM', iv }, await deriveKey(password, salt), new TextEncoder().encode(json));
    return JSON.stringify({ app: 'mazoghi-money-enc', v: 1, salt: b64(salt), iv: b64(iv), data: b64(new Uint8Array(ct)) });
  }
  const isEncryptedBackup = text => { try { return JSON.parse(text).app === 'mazoghi-money-enc'; } catch (e) { return false; } };
  async function decryptBackup(text, password) {
    const o = JSON.parse(text); if (o.app !== 'mazoghi-money-enc') throw new Error('Not an encrypted backup');
    try {
      const pt = await globalThis.crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(o.iv) }, await deriveKey(password, unb64(o.salt)), unb64(o.data));
      return new TextDecoder().decode(pt);
    } catch (e) { throw new Error('Wrong password or corrupted file'); }
  }


  /* ---- PIN attempts: persistent throttling against guessing. 5 failures -> 30s, then doubling up to 1h. ---- */
  const lockWait = (st, now) => Math.max(0, (st.settings.lockUntil || 0) - now);
  async function tryPin(pin, st, now = Date.now()) {
    if (!st.settings.pinHash) return { ok: true };
    const w = lockWait(st, now); if (w > 0) return { ok: false, waitMs: w };
    if (await verifyPin(pin, st)) { st.settings.fails = 0; st.settings.lockUntil = 0; return { ok: true, changed: true }; }
    const f = (st.settings.fails || 0) + 1; st.settings.fails = f;
    if (f % 5 === 0) st.settings.lockUntil = now + Math.min(3600e3, 30e3 * Math.pow(2, f / 5 - 1));
    return { ok: false, waitMs: lockWait(st, now), changed: true };
  }

  /* ---- Migration from the original app: {pin, transactions:[{id,type,title,amount,timestamp,dateStr}]} ---- */
  async function migrateLegacy(old) {
    const st = emptyState();
    const wallet = { id: 'acc_main', name: 'المحفظة', type: 'cash', currency: BASE, opening: 0, archived: false, createdAt: nowIso() };
    st.accounts.push(wallet);
    const incomeCats = st.categories.filter(c => c.kind === 'income'), otherExp = st.categories.find(c => c.kind === 'expense' && c.ar === 'أخرى');
    for (const t of (old && old.transactions) || []) {
      const isInc = t.type === 'income';
      const cat = isInc ? (incomeCats.find(c => String(t.title).startsWith(c.ar)) || incomeCats[3]) : otherExp;
      st.transactions.push({
        id: t.id, type: isInc ? 'income' : 'expense', accountId: wallet.id, categoryId: cat.id, title: t.title || '',
        amount: toMinor(t.amount, BASE), currency: BASE, ts: t.timestamp || nowIso(), note: '', legacy: true
      });
    }
    if (old && old.pin) { const h = await hashPin(old.pin); st.settings.pinHash = h.hash; st.settings.pinSalt = h.salt; }
    st.log.push({ id: uid(), ts: nowIso(), action: 'migrate', entity: 'system', entityId: null, summary: 'Imported ' + st.transactions.length + ' legacy transactions' });
    return st;
  }

  const ensure = x => { for (const k of ['accounts', 'categories', 'transactions', 'debts', 'budgets', 'goals', 'reminders', 'rateHistory', 'log']) if (!Array.isArray(x[k])) x[k] = []; if (!x.rates) x.rates = {}; if (!x.settings) x.settings = emptyState().settings; return x; };

  /* ---- Store ---- */
  function createStore(adapter, initial) {
    let st = initial || emptyState();
    const save = (touch = true) => {
      if (!adapter) return;
      if (touch) { st.updatedAt = nowIso(); st.rev = (st.rev || 0) + 1; }   // rev is a monotonic change counter (timestamps can collide)
      const at = Number(adapter.get('mm_snapshot_at') || 0), now = Date.now();
      if (now - at > SNAP_EVERY_MS) { const prev = adapter.get(KEY); if (prev) { adapter.set('mm_snapshot', prev); adapter.set('mm_snapshot_at', String(now)); } }   // daily safety copy of the last good state
      adapter.set(KEY, JSON.stringify(st));
    };
    const log = (action, entity, entityId, summary) => { st.log.push({ id: uid(), ts: nowIso(), action, entity, entityId, summary }); if (st.log.length > LOG_CAP) st.log.splice(0, st.log.length - LOG_CAP); };
    const acc = id => { const a = st.accounts.find(x => x.id === id); if (!a) throw new Error('Account not found'); return a; };
    const posInt = n => { if (!Number.isInteger(n) || n <= 0) throw new Error('Amount must be a positive integer (minor units)'); if (n > MAX_MINOR) throw new Error('Amount too large'); };

    const api = {
      get state() { return st; },
      save,
      markSynced(remoteVersion) { st.sync = { remoteVersion, lastSyncedRev: st.rev || 0, at: nowIso() }; save(false); },
      load() { const raw = adapter && adapter.get(KEY); if (raw) st = ensure(JSON.parse(raw)); return st; },

      addAccount({ name, type = 'cash', currency = st.settings.baseCurrency, opening = 0 }) {
        if (!name || !name.trim()) throw new Error('Account name required'); dec(currency); name = clean(name, 60, 'Name');
        if (!Number.isInteger(opening) || Math.abs(opening) > MAX_MINOR) throw new Error('Invalid opening balance');
        const a = { id: uid(), name, type, currency, opening, archived: false, createdAt: nowIso() };
        st.accounts.push(a); log('add', 'account', a.id, a.name); save(); return a;
      },
      archiveAccount(id) { const a = acc(id); a.archived = true; log('archive', 'account', id, a.name); save(); },   // accounts are never deleted

      addTransaction({ type, accountId, categoryId, amount, title = '', note = '', ts }) {
        if (type !== 'income' && type !== 'expense') throw new Error('Invalid type'); posInt(amount); title = clean(title, 120, 'Title'); note = clean(note, 500, 'Note'); checkTs(ts);
        const a = acc(accountId); if (a.archived) throw new Error('Account is archived');
        const t = { id: uid(), type, accountId, categoryId: categoryId || null, title, note, amount, currency: a.currency, ts: ts || nowIso() };
        st.transactions.push(t); log('add', 'transaction', t.id, type + ' ' + amount); save(); return t;
      },
      addTransfer({ fromId, toId, amount, toAmount, ts, note = '' }) {
        posInt(amount); checkTs(ts); note = clean(note, 500, 'Note'); if (fromId === toId) throw new Error('Cannot transfer to the same account');
        const a = acc(fromId), b = acc(toId); if (a.archived || b.archived) throw new Error('Account is archived');
        let inAmt = toAmount;
        if (inAmt == null) inAmt = convert(amount, a.currency, b.currency, st.rates); else posInt(inAmt);
        const t = { id: uid(), type: 'transfer', accountId: fromId, toAccountId: toId, amount, toAmount: inAmt, currency: a.currency, toCurrency: b.currency, note, ts: ts || nowIso() };
        st.transactions.push(t); log('add', 'transaction', t.id, 'transfer ' + amount); save(); return t;
      },
      deleteTransaction(id) {   // reversible: kept in the log with a full snapshot
        const i = st.transactions.findIndex(t => t.id === id); if (i < 0) throw new Error('Transaction not found');
        const [t] = st.transactions.splice(i, 1); log('delete', 'transaction', id, JSON.stringify(t));
        if (t.debtId) { const d = st.debts.find(x => x.id === t.debtId); if (d) { d.payments = d.payments.filter(p => p.txId !== t.id); d.closed = false; } }   // deleting a debt payment reopens the debt
        save(); return t;
      },
      setRate(cur, rate) {
        if (cur === st.settings.baseCurrency) throw new Error('Base currency rate is fixed at 1'); dec(cur);
        if (!(rate > 0)) throw new Error('Rate must be positive');
        st.rates[cur] = rate; st.rateHistory.push({ ts: nowIso(), cur, rate }); log('rate', 'rate', cur, String(rate)); save();
      },

      balance(accountId) {
        const a = acc(accountId); let b = a.opening || 0;
        for (const t of st.transactions) {
          if (t.type === 'income' && t.accountId === accountId) b += t.amount;
          else if (t.type === 'expense' && t.accountId === accountId) b -= t.amount;
          else if (t.type === 'transfer') { if (t.accountId === accountId) b -= t.amount; if (t.toAccountId === accountId) b += t.toAmount; }
        }
        return b;
      },
      totalBalance(cur = st.settings.baseCurrency) {
        return st.accounts.filter(a => !a.archived).reduce((s, a) => s + convert(api.balance(a.id), a.currency, cur, st.rates), 0);
      },
      totals(accountId) {   // income / expense only; transfers are neither
        let inc = 0, exp = 0;
        for (const t of st.transactions) if (!accountId || t.accountId === accountId) { if (t.type === 'income') inc += t.amount; if (t.type === 'expense') exp += t.amount; }
        return { income: inc, expense: exp };
      },

      /* ---- Debts: kind 'owed_to_me' (someone owes me) | 'i_owe'. Creating a debt does not move money; payments may. ---- */
      addDebt({ kind, person, amount, currency = st.settings.baseCurrency, dueDate = null, note = '' }) {
        if (kind !== 'owed_to_me' && kind !== 'i_owe') throw new Error('Invalid debt kind'); if (!person || !person.trim()) throw new Error('Person required'); person = clean(person, 60, 'Person'); note = clean(note, 500, 'Note'); if (dueDate && isNaN(new Date(dueDate))) throw new Error('Invalid date'); posInt(amount); dec(currency);
        const d = { id: uid(), kind, person, principal: amount, currency, dueDate, note, payments: [], closed: false, createdAt: nowIso() };
        st.debts.push(d); log('add', 'debt', d.id, kind + ' ' + amount); save(); return d;
      },
      debtRemaining(id) { const d = st.debts.find(x => x.id === id); if (!d) throw new Error('Debt not found'); return d.principal - d.payments.reduce((s, p) => s + p.amount, 0); },
      addDebtPayment({ debtId, amount, accountId = null, ts }) {
        const d = st.debts.find(x => x.id === debtId); if (!d) throw new Error('Debt not found'); posInt(amount);
        if (amount > api.debtRemaining(debtId)) throw new Error('Payment exceeds remaining debt');
        let txId = null;
        if (accountId) {
          const a = acc(accountId); if (a.currency !== d.currency) throw new Error('Account currency must match the debt currency');
          const tx = api.addTransaction({ type: d.kind === 'owed_to_me' ? 'income' : 'expense', accountId, amount, title: d.person, ts }); tx.debtId = d.id; txId = tx.id; save();
        }
        const p = { id: uid(), amount, ts: ts || nowIso(), txId }; d.payments.push(p);
        if (api.debtRemaining(debtId) === 0) d.closed = true;
        log('pay', 'debt', d.id, String(amount)); save(); return p;
      },

      /* ---- Budgets: one monthly limit per expense category, in the base currency ---- */
      setBudget(categoryId, limit) {
        const c = st.categories.find(x => x.id === categoryId); if (!c || c.kind !== 'expense') throw new Error('Budget needs an expense category'); posInt(limit);
        let b = st.budgets.find(x => x.categoryId === categoryId);
        if (b) b.limit = limit; else { b = { id: uid(), categoryId, limit }; st.budgets.push(b); }
        log('budget', 'budget', b.id, String(limit)); save(); return b;
      },
      removeBudget(categoryId) { const i = st.budgets.findIndex(x => x.categoryId === categoryId); if (i >= 0) { log('remove', 'budget', st.budgets[i].id, JSON.stringify(st.budgets[i])); st.budgets.splice(i, 1); save(); } },
      budgetStatus(month = monthKey(new Date())) {
        return st.budgets.map(b => {
          let spent = 0, unconverted = 0;
          for (const t of st.transactions) if (t.type === 'expense' && t.categoryId === b.categoryId && monthKey(t.ts) === month) {
            try { spent += convert(t.amount, t.currency, st.settings.baseCurrency, st.rates); } catch (e) { unconverted++; }
          }
          return { id: b.id, categoryId: b.categoryId, limit: b.limit, spent, remaining: b.limit - spent, pct: Math.round(spent / b.limit * 100), over: spent > b.limit, unconverted };
        });
      },

      /* ---- Savings goals: earmarked progress, independent of account balances ---- */
      addGoal({ name, target, currency = st.settings.baseCurrency, deadline = null }) {
        if (!name || !name.trim()) throw new Error('Goal name required'); name = clean(name, 60, 'Name'); if (deadline && isNaN(new Date(deadline))) throw new Error('Invalid date'); posInt(target); dec(currency);
        const g = { id: uid(), name, target, currency, deadline, contributions: [], createdAt: nowIso() };
        st.goals.push(g); log('add', 'goal', g.id, g.name); save(); return g;
      },
      contribute(goalId, amount, ts) {
        const g = st.goals.find(x => x.id === goalId); if (!g) throw new Error('Goal not found'); posInt(amount);
        g.contributions.push({ id: uid(), amount, ts: ts || nowIso() }); log('contribute', 'goal', goalId, String(amount)); save(); return g;
      },
      goalProgress(goalId) {
        const g = st.goals.find(x => x.id === goalId); if (!g) throw new Error('Goal not found');
        const saved = g.contributions.reduce((s, c) => s + c.amount, 0);
        return { saved, target: g.target, pct: Math.min(100, Math.floor(saved / g.target * 100)), done: saved >= g.target };
      },

      /* ---- Reminders ---- */
      addReminder({ title, due, repeat = 'none' }) {
        if (!title || !title.trim() || !due || isNaN(new Date(due))) throw new Error('Title and valid due date required'); title = clean(title, 120, 'Title'); if (!['none', 'weekly', 'monthly'].includes(repeat)) throw new Error('Invalid repeat');
        const r = { id: uid(), title, due: new Date(due).toISOString(), repeat, done: false }; st.reminders.push(r); log('add', 'reminder', r.id, r.title); save(); return r;
      },
      completeReminder(id) {
        const r = st.reminders.find(x => x.id === id); if (!r) throw new Error('Reminder not found');
        if (r.repeat === 'none') r.done = true; else r.due = addPeriod(r.due, r.repeat);
        log('done', 'reminder', id, r.title); save(); return r;
      },

      /* ---- Alerts: computed on demand, never stored ---- */
      alerts(now = new Date()) {
        const out = [];
        for (const r of st.reminders) if (!r.done && new Date(r.due) <= new Date(now)) out.push({ kind: 'reminder', id: r.id, title: r.title, due: r.due });
        for (const d of st.debts) if (!d.closed && d.dueDate) { const n = dayDiff(d.dueDate, now); if (n <= 3) out.push({ kind: 'debt', id: d.id, person: d.person, debtKind: d.kind, days: n, overdue: n < 0 }); }
        for (const b of api.budgetStatus(monthKey(now))) if (b.pct >= 80) out.push({ kind: 'budget', id: b.id, categoryId: b.categoryId, pct: b.pct, over: b.over });
        return out;
      },

      transactionsIn({ from = null, to = null } = {}) {
        const lo = from ? new Date(from + 'T00:00:00') : null, hi = to ? new Date(to + 'T23:59:59.999') : null;
        return st.transactions.filter(t => { const d = new Date(t.ts); return !((lo && d < lo) || (hi && d > hi)); }).sort((a, b) => new Date(a.ts) - new Date(b.ts));
      },
      /* ---- Reports (base currency). from/to: 'YYYY-MM-DD' inclusive, or null for open-ended. Transfers are excluded. ---- */
      report({ from = null, to = null } = {}) {
        const lo = from ? new Date(from + 'T00:00:00') : null, hi = to ? new Date(to + 'T23:59:59.999') : null, bc = st.settings.baseCurrency;
        let income = 0, expense = 0, unconverted = 0; const cat = {}, mon = {};
        for (const t of st.transactions) {
          if (t.type === 'transfer') continue; const d = new Date(t.ts); if ((lo && d < lo) || (hi && d > hi)) continue;
          let v; try { v = convert(t.amount, t.currency, bc, st.rates); } catch (e) { unconverted++; continue; }
          const m = monthKey(d); mon[m] = mon[m] || { month: m, income: 0, expense: 0 };
          if (t.type === 'income') { income += v; mon[m].income += v; } else { expense += v; mon[m].expense += v; cat[t.categoryId || 'none'] = (cat[t.categoryId || 'none'] || 0) + v; }
        }
        const byCategory = Object.entries(cat).map(([categoryId, total]) => ({ categoryId, total, pct: expense ? Math.round(total / expense * 100) : 0 })).sort((a, b) => b.total - a.total);
        const accounts = st.accounts.filter(a => !a.archived).map(a => ({ id: a.id, name: a.name, currency: a.currency, balance: api.balance(a.id) }));
        let owedToMe = 0, iOwe = 0;
        for (const d of st.debts) if (!d.closed) { try { const v = convert(api.debtRemaining(d.id), d.currency, bc, st.rates); if (d.kind === 'owed_to_me') owedToMe += v; else iOwe += v; } catch (e) { unconverted++; } }
        return { income, expense, net: income - expense, unconverted, byCategory, byMonth: Object.values(mon).sort((a, b) => a.month < b.month ? -1 : 1), accounts, debts: { owedToMe, iOwe } };
      },

      /* ---- Notification plan for the native scheduler: upcoming moments the phone should alert at ---- */
      notificationPlan(now = new Date(), maxRepeats = 3) {
        const out = [], n = new Date(now).getTime();
        for (const r of st.reminders) if (!r.done) {
          let due = r.due;
          for (let i = 0; i < (r.repeat === 'none' ? 1 : maxRepeats); i++) { if (new Date(due).getTime() > n) out.push({ key: 'r_' + r.id + '_' + i, kind: 'reminder', title: r.title, at: new Date(due).getTime() }); if (r.repeat === 'none') break; due = addPeriod(due, r.repeat); }
        }
        for (const d of st.debts) if (!d.closed && d.dueDate) { const at = new Date(d.dueDate.slice(0, 10) + 'T09:00:00').getTime(); if (at > n) out.push({ key: 'd_' + d.id, kind: 'debt', person: d.person, debtKind: d.kind, at }); }
        return out.sort((a, b) => a.at - b.at);
      },

      exportBackup() { return JSON.stringify({ app: 'mazoghi-money', schema: SCHEMA, exportedAt: nowIso(), data: st }); },
      importBackup(json) {
        const b = JSON.parse(json);
        if (!b || b.app !== 'mazoghi-money' || !b.data || !Array.isArray(b.data.accounts) || !Array.isArray(b.data.transactions)) throw new Error('Invalid backup file');
        if (adapter) adapter.set('mm_prev_snapshot', JSON.stringify(st));   // safety copy before replacing
        st = ensure(b.data); delete st.sync; log('restore', 'system', null, 'Backup restored'); save(); return st;
      }
    };
    return api;
  }

  /* Opens the store; if no v2 data exists but the original app's data does, migrates it (original key is left untouched). */
  async function open(adapter) {
    const raw = adapter.get(KEY), marker = adapter.get('mm_initialized');
    const fromSnapshot = (why) => {   // main file unreadable or missing: use the daily snapshot, keep what is left aside, never start empty over data
      const snap = adapter.get('mm_snapshot'); if (!snap) throw why;
      if (raw) adapter.set('mm_corrupt', raw);
      const s = createStore(adapter, ensure(JSON.parse(snap))); s.recovered = true; s.save(false); return s;
    };
    if (raw) {
      let s; try { s = createStore(adapter); s.load(); } catch (e) { return fromSnapshot(e); }
      if (!marker) adapter.set('mm_initialized', '1');   // installs created before the marker existed
      return s;
    }
    if (marker) return fromSnapshot(new Error('Data file missing'));   // it existed before: a missing file is an anomaly, not a fresh install
    const legacy = adapter.get(LEGACY_KEY);
    const s = createStore(adapter, legacy ? await migrateLegacy(JSON.parse(legacy)) : emptyState());
    adapter.set(KEY, JSON.stringify(s.state)); adapter.set('mm_initialized', '1');
    return s;
  }

  return { monthKey, SCHEMA, BASE, KEY, LEGACY_KEY, CURRENCIES, toMinor, fromMinor, format, convert, hashPin, verifyPin, tryPin, lockWait, encryptBackup, decryptBackup, isEncryptedBackup, migrateLegacy, createStore, open, emptyState };
});
