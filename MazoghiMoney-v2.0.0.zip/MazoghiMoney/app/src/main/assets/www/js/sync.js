/* Optional cloud sync (future). Nothing here talks to a network: a provider object supplies the transport.
   Provider contract (all async):
     pull()                      -> { version: string|null, blob: string|null }   current remote copy
     push(blob, expectedVersion) -> { version }   must throw an Error('CONFLICT') if the remote changed since expectedVersion
   The blob is always the password-encrypted backup, so a provider only ever sees ciphertext.
   Policy: never overwrite silently. If both sides changed, report 'conflict' and let the user choose via resolve(). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(); else root.MMSync = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const MMc = () => (typeof require === 'function' && typeof module === 'object') ? require('./engine.js') : root.MM;
  const root = typeof self !== 'undefined' ? self : this;

  async function pushLocal(store, provider, password, sync) {
    const blob = await MMc().encryptBackup(store.exportBackup(), password);
    const r = await provider.push(blob, sync.remoteVersion || null);
    store.markSynced(r.version); return { status: 'pushed', version: r.version };
  }
  async function pullRemote(store, remote, password, version) {
    const json = await MMc().decryptBackup(remote.blob, password);   // wrong password throws before anything changes
    store.importBackup(json);                                        // keeps a safety snapshot of the local state
    store.markSynced(version); return { status: 'pulled', version };
  }

  async function run(store, provider, password) {
    if (!password) throw new Error('Sync password required');
    const st = store.state, sync = st.sync || {}, remote = await provider.pull();
    if (!remote.blob) return pushLocal(store, provider, password, { remoteVersion: null });
    const localChanged = (st.rev || 0) !== (sync.lastSyncedRev || 0), remoteChanged = remote.version !== (sync.remoteVersion || null);
    // a never-modified device (rev 0, never synced) has nothing to lose, so it simply pulls
    if (localChanged && remoteChanged) return { status: 'conflict', remoteVersion: remote.version };
    if (remoteChanged) return pullRemote(store, remote, password, remote.version);
    if (localChanged) return pushLocal(store, provider, password, sync);
    return { status: 'up-to-date' };
  }
  /* choice: 'local' overwrites the remote copy, 'remote' replaces local data (after a safety snapshot) */
  async function resolve(store, provider, password, choice) {
    const remote = await provider.pull();
    if (choice === 'remote') return pullRemote(store, remote, password, remote.version);
    return pushLocal(store, provider, password, { remoteVersion: remote.version });
  }

  /* In-memory provider used by tests and as a reference implementation of the contract. */
  function memoryProvider() {
    let version = null, blob = null, n = 0;
    return { pull: async () => ({ version, blob }), push: async (b, expected) => { if (expected !== version) throw new Error('CONFLICT'); blob = b; version = 'v' + (++n); return { version }; }, _tamper: b => { blob = b; version = 'v' + (++n); } };
  }
  return { run, resolve, memoryProvider };
});
