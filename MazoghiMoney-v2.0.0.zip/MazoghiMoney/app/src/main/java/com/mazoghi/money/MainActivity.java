package com.mazoghi.money;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    static final int REQ_SAVE = 101, REQ_PICK = 102, REQ_NOTIF = 103;
    private static final int MAX_IMPORT_BYTES = 20 * 1024 * 1024;
    private WebView webView;
    byte[] pendingSave;

    WebView webView() { return webView; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#0f172a"));
        w.setNavigationBarColor(Color.parseColor("#0f172a"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0f172a"));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // same localStorage as the original app: data is preserved
        s.setAllowFileAccess(true);            // needed for file:///android_asset
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setBlockNetworkLoads(true);          // fully offline: nothing is ever loaded from the internet
        webView.addJavascriptInterface(new NativeStore(this), "NativeStore");
        webView.addJavascriptInterface(new NativeBridge(this), "NativeBridge");
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);

        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        final Uri uri = (res == RESULT_OK && data != null) ? data.getData() : null;
        if (req == REQ_SAVE) {
            final byte[] bytes = pendingSave;
            pendingSave = null;
            if (uri == null || bytes == null) { callJs("window.__onFileSaved&&window.__onFileSaved(false)"); return; }
            new Thread(() -> {
                boolean ok = false;
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) { out.write(bytes); out.flush(); ok = true; } catch (Exception ignored) { }
                callJs("window.__onFileSaved&&window.__onFileSaved(" + ok + ")");
            }).start();
        } else if (req == REQ_PICK) {
            if (uri == null) { callJs("window.__onFilePicked&&window.__onFilePicked(null)"); return; }
            new Thread(() -> {
                String text = null;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    ByteArrayOutputStream buf = new ByteArrayOutputStream();
                    byte[] b = new byte[8192];
                    int n, total = 0;
                    while ((n = in.read(b)) > 0) { total += n; if (total > MAX_IMPORT_BYTES) throw new Exception("too large"); buf.write(b, 0, n); }
                    text = new String(buf.toByteArray(), StandardCharsets.UTF_8);
                } catch (Exception ignored) { }
                callJs("window.__onFilePicked&&window.__onFilePicked(" + (text == null ? "null" : JSONObject.quote(text)) + ")");
            }).start();
        }
    }

    private void callJs(String code) { runOnUiThread(() -> webView.evaluateJavascript(code, null)); }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        webView.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
