package com.mazoghi.money;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

/** Features the web UI cannot do alone. Exposed to the page as window.NativeBridge. Results come back through window.__onXxx callbacks. */
public class NativeBridge {
    private final MainActivity act;

    public NativeBridge(MainActivity act) { this.act = act; }

    private void js(String code) { act.runOnUiThread(() -> act.webView().evaluateJavascript(code, null)); }

    @JavascriptInterface
    public String capabilities() {
        boolean bio = false;
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                BiometricManager bm = act.getSystemService(BiometricManager.class);
                bio = bm != null && bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception ignored) { }
        }
        return "{\"biometric\":" + bio + ",\"files\":true,\"print\":true,\"notifications\":true,\"secure\":true}";
    }

    /** Blocks screenshots, screen recording and the recent-apps thumbnail while on. */
    @JavascriptInterface
    public void setSecure(boolean on) {
        act.runOnUiThread(() -> {
            if (on) act.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
            else act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        });
    }

    /** Opens the system "save as" dialog; the user picks the location. Result: window.__onFileSaved(true|false). */
    @JavascriptInterface
    public void saveFile(String name, String mime, String base64) {
        final byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
        act.runOnUiThread(() -> {
            act.pendingSave = bytes;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_TITLE, name);
            act.startActivityForResult(i, MainActivity.REQ_SAVE);
        });
    }

    /** Opens the system file picker. Result: window.__onFilePicked(text | null). */
    @JavascriptInterface
    public void pickFile() {
        act.runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            act.startActivityForResult(i, MainActivity.REQ_PICK);
        });
    }

    /** Prints the current page; the Android print dialog offers "Save as PDF" (renders Arabic exactly as shown). */
    @JavascriptInterface
    public void printPage(String title) {
        act.runOnUiThread(() -> {
            PrintManager pm = (PrintManager) act.getSystemService(MainActivity.PRINT_SERVICE);
            if (pm == null) return;
            pm.print(title, act.webView().createPrintDocumentAdapter(title), new PrintAttributes.Builder().build());
        });
    }

    /** Fingerprint / face prompt. Only unlocks the app; the PIN always remains available. Result: window.__onBiometric(true|false). */
    @JavascriptInterface
    public void authenticate(String title, String cancelLabel) {
        if (Build.VERSION.SDK_INT < 28) { js("window.__onBiometric&&window.__onBiometric(false)"); return; }
        act.runOnUiThread(() -> {
            BiometricPrompt prompt = new BiometricPrompt.Builder(act)
                    .setTitle(title)
                    .setNegativeButton(cancelLabel, act.getMainExecutor(), (DialogInterface.OnClickListener) (d, w) -> js("window.__onBiometric&&window.__onBiometric(false)"))
                    .build();
            prompt.authenticate(new CancellationSignal(), act.getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { js("window.__onBiometric&&window.__onBiometric(true)"); }
                @Override public void onAuthenticationError(int code, CharSequence msg) { js("window.__onBiometric&&window.__onBiometric(false)"); }
            });
        });
    }

    /** json: [{"key":"..","title":"..","at":epochMillis}]. Replaces every previously scheduled alert. */
    @JavascriptInterface
    public void scheduleNotifications(String json) {
        act.getSharedPreferences(Notifier.PREFS, 0).edit().putString("plan", json).apply();
        act.runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33 && act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                act.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, MainActivity.REQ_NOTIF);
            }
            Notifier.schedule(act);
        });
    }
}
