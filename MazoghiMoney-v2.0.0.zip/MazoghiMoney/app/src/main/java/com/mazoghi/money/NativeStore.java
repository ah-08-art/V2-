package com.mazoghi.money;

import android.content.Context;
import android.webkit.JavascriptInterface;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/** Durable key/value storage in the app's private directory (atomic write + fsync). Exposed to the page as window.NativeStore. */
public class NativeStore {
    public static final String READ_ERROR = "__READ_ERROR__";
    private final File dir;

    public NativeStore(Context ctx) {
        dir = new File(ctx.getFilesDir(), "mm");
        if (!dir.exists()) dir.mkdirs();
    }

    private File file(String key) {
        if (key == null || !key.matches("[A-Za-z0-9_]{1,64}")) throw new IllegalArgumentException("bad key");
        return new File(dir, key + ".json");
    }

    /** Returns null when the key does not exist, READ_ERROR when it exists but cannot be read (never treated as "empty"). */
    @JavascriptInterface
    public synchronized String get(String key) {
        try {
            File f = file(key);
            if (!f.exists()) return null;
            try (FileInputStream in = new FileInputStream(f)) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return READ_ERROR;
        }
    }

    @JavascriptInterface
    public synchronized boolean set(String key, String value) {
        try {
            File f = file(key), tmp = new File(dir, key + ".tmp");
            try (FileOutputStream out = new FileOutputStream(tmp)) {
                out.write(value.getBytes(StandardCharsets.UTF_8));
                out.flush();
                out.getFD().sync();
            }
            return tmp.renameTo(f);
        } catch (Exception e) {
            return false;
        }
    }
}
