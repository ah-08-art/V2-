package com.mazoghi.money;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** Schedules local alerts with AlarmManager (inexact, no special permission) from the plan saved by the page. */
public final class Notifier {
    public static final String PREFS = "mm_notif", CHANNEL = "mm_alerts";
    private Notifier() { }

    private static PendingIntent pi(Context c, String key, String title) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("title", title == null ? "" : title);
        i.putExtra("key", key);
        return PendingIntent.getBroadcast(c, key.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static void schedule(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, 0);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            JSONArray old = new JSONArray(p.getString("scheduled", "[]"));
            for (int k = 0; k < old.length(); k++) am.cancel(pi(c, old.getString(k), ""));
            JSONArray plan = new JSONArray(p.getString("plan", "[]"));
            JSONArray keys = new JSONArray();
            long now = System.currentTimeMillis();
            for (int k = 0; k < plan.length(); k++) {
                JSONObject o = plan.getJSONObject(k);
                long at = o.getLong("at");
                if (at <= now) continue;
                String key = o.getString("key");
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, key, o.optString("title", "")));
                keys.put(key);
            }
            p.edit().putString("scheduled", keys.toString()).apply();
        } catch (Exception ignored) { }
    }

    public static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Mazoghi Money", NotificationManager.IMPORTANCE_DEFAULT));
        }
    }
}
