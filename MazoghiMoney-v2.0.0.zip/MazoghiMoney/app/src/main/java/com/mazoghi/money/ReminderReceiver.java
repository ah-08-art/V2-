package com.mazoghi.money;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String title = in.getStringExtra("title"), key = in.getStringExtra("key");
        if (title == null || key == null) return;
        Notifier.ensureChannel(c);
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, Notifier.CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_launcher).setContentTitle("Mazoghi Money").setContentText(title).setContentIntent(open).setAutoCancel(true);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(key.hashCode(), b.build());
    }
}
