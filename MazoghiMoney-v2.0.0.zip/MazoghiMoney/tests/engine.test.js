const test = require('node:test'), assert = require('node:assert/strict');
const MM = require('../app/src/main/assets/www/js/engine.js');
const mem = () => { const m = {}; return { get: k => (k in m ? m[k] : null), set: (k, v) => { m[k] = v; }, m }; };

test('money: LYD uses 3 decimals, no float drift', () => {
  assert.equal(MM.toMinor(0.1 + 0.2, 'LYD'), 300);
  assert.equal(MM.toMinor(12.345, 'LYD'), 12345);
  assert.equal(MM.toMinor(10.05, 'USD'), 1005);
  assert.equal(MM.format(1234567, 'LYD', 'ar'), '1,234.567 د.ل');
  assert.equal(MM.format(-500, 'LYD', 'en'), '-0.500 LYD');
});

test('convert: via base rates, same currency untouched, missing rate throws', () => {
  const rates = { USD: 4.8 };
  assert.equal(MM.convert(1000, 'USD', 'LYD', rates), 48000);          // 10.00 USD -> 48.000 LYD
  assert.equal(MM.convert(48000, 'LYD', 'USD', rates), 1000);
  assert.equal(MM.convert(777, 'LYD', 'LYD', rates), 777);
  assert.throws(() => MM.convert(100, 'EUR', 'LYD', rates), /Missing rate/);
});

test('ledger: balances, totals, transfers are neutral for totals', () => {
  const s = MM.createStore(mem());
  const a = s.addAccount({ name: 'Cash', opening: 100000 });
  const b = s.addAccount({ name: 'Bank' });
  s.addTransaction({ type: 'income', accountId: a.id, amount: 50000 });
  s.addTransaction({ type: 'expense', accountId: a.id, amount: 20000 });
  s.addTransfer({ fromId: a.id, toId: b.id, amount: 30000 });
  assert.equal(s.balance(a.id), 100000 + 50000 - 20000 - 30000);
  assert.equal(s.balance(b.id), 30000);
  assert.equal(s.totalBalance(), 130000);            // transfer does not change the total
  assert.deepEqual(s.totals(), { income: 50000, expense: 20000 });
});

test('multi-currency transfer uses stored rate; explicit toAmount wins', () => {
  const s = MM.createStore(mem());
  const l = s.addAccount({ name: 'LYD', opening: 96000 });
  const u = s.addAccount({ name: 'USD', currency: 'USD' });
  s.setRate('USD', 4.8);
  s.addTransfer({ fromId: l.id, toId: u.id, amount: 48000 });          // 48 LYD -> 10 USD
  assert.equal(s.balance(u.id), 1000);
  s.addTransfer({ fromId: l.id, toId: u.id, amount: 48000, toAmount: 990 }); // actual bank rate
  assert.equal(s.balance(u.id), 1990);
  assert.equal(s.totalBalance('LYD'), 0 + MM.convert(1990, 'USD', 'LYD', { USD: 4.8 }));
});

test('validation: bad input rejected, accounts archived not deleted', () => {
  const s = MM.createStore(mem());
  const a = s.addAccount({ name: 'A' }), b = s.addAccount({ name: 'B' });
  assert.throws(() => s.addTransaction({ type: 'income', accountId: a.id, amount: 0 }));
  assert.throws(() => s.addTransaction({ type: 'income', accountId: a.id, amount: 1.5 }));
  assert.throws(() => s.addTransaction({ type: 'bogus', accountId: a.id, amount: 5 }));
  assert.throws(() => s.addTransfer({ fromId: a.id, toId: a.id, amount: 5 }));
  assert.throws(() => s.setRate('LYD', 2));
  assert.throws(() => s.addAccount({ name: '  ' }));
  s.archiveAccount(b.id);
  assert.equal(s.state.accounts.length, 2);
  assert.throws(() => s.addTransaction({ type: 'income', accountId: b.id, amount: 5 }));
});

test('delete keeps a full snapshot in the audit log', () => {
  const s = MM.createStore(mem());
  const a = s.addAccount({ name: 'A' });
  const t = s.addTransaction({ type: 'expense', accountId: a.id, amount: 700, title: 'x' });
  s.deleteTransaction(t.id);
  assert.equal(s.state.transactions.length, 0);
  const entry = s.state.log.find(l => l.action === 'delete');
  assert.equal(JSON.parse(entry.summary).amount, 700);
});

test('migration: every legacy transaction and the PIN are preserved', async () => {
  const old = { pin: '4321', transactions: [
    { id: 1700000000001, type: 'income', title: 'مرتب (مايو)', amount: 1500.5, timestamp: '2025-05-01T10:00:00.000Z', dateStr: '١‏/٥‏/٢٠٢٥' },
    { id: 1700000000002, type: 'income', title: 'عمل حر', amount: 200, timestamp: '2025-05-02T10:00:00.000Z', dateStr: 'x' },
    { id: 1700000000003, type: 'expense', title: 'بنزين', amount: 35.25, timestamp: '2025-05-03T10:00:00.000Z', dateStr: 'x' }
  ] };
  const ad = mem(); ad.set(MM.LEGACY_KEY, JSON.stringify(old));
  const s = await MM.open(ad);
  assert.equal(s.state.transactions.length, 3);
  assert.deepEqual(s.state.transactions.map(t => t.id), [1700000000001, 1700000000002, 1700000000003]);
  assert.equal(s.state.transactions[0].title, 'مرتب (مايو)');
  assert.equal(s.balance('acc_main'), MM.toMinor(1500.5 + 200 - 35.25, 'LYD'));     // same total as the old app: 1665.250 LYD
  assert.equal(s.state.categories.find(c => c.id === s.state.transactions[1].categoryId).ar, 'عمل حر');
  assert.equal(ad.get(MM.LEGACY_KEY), JSON.stringify(old));                         // original data untouched
  assert.equal(JSON.stringify(s.state).includes('4321'), false);                    // PIN never stored in clear
  assert.equal(await MM.verifyPin('4321', s.state), true);
  assert.equal(await MM.verifyPin('0000', s.state), false);
  const again = await MM.open(ad);                                                  // second launch: no re-migration
  assert.equal(again.state.transactions.length, 3);
  assert.equal(again.state.log.filter(l => l.action === 'migrate').length, 1);
});

test('fresh install opens empty; persistence round-trips', async () => {
  const ad = mem(); const s = await MM.open(ad);
  const a = s.addAccount({ name: 'Cash', opening: 5000 });
  const s2 = await MM.open(ad);
  assert.equal(s2.balance(a.id), 5000);
  assert.equal(s2.state.settings.baseCurrency, 'LYD');
});

test('backup: export/import round-trip, invalid file rejected, safety snapshot kept', async () => {
  const ad = mem(); const s = await MM.open(ad);
  const a = s.addAccount({ name: 'Cash' }); s.addTransaction({ type: 'income', accountId: a.id, amount: 900 });
  const dump = s.exportBackup();
  s.addTransaction({ type: 'income', accountId: a.id, amount: 100 });
  s.importBackup(dump);
  assert.equal(s.balance(a.id), 900);
  assert.ok(ad.get('mm_prev_snapshot'));
  assert.throws(() => s.importBackup('{"app":"other"}'), /Invalid backup/);
  assert.equal(s.balance(a.id), 900);                                               // failed import changes nothing
});
