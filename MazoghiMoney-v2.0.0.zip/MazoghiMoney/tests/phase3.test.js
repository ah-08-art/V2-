const test = require('node:test'), assert = require('node:assert/strict');
const MM = require('../app/src/main/assets/www/js/engine.js');
const mem = () => { const m = {}; return { get: k => (k in m ? m[k] : null), set: (k, v) => { m[k] = v; } }; };
const fresh = () => { const s = MM.createStore(mem()); const a = s.addAccount({ name: 'Cash', opening: 1000000 }); return { s, a }; };
const cat = (s, kind, ar) => s.state.categories.find(c => c.kind === kind && c.ar === ar).id;

test('debt owed to me: partial payment becomes income, closes when fully paid', () => {
  const { s, a } = fresh();
  const d = s.addDebt({ kind: 'owed_to_me', person: 'أحمد', amount: 500000 });
  assert.equal(s.balance(a.id), 1000000);                       // creating a debt moves no money
  s.addDebtPayment({ debtId: d.id, amount: 200000, accountId: a.id });
  assert.equal(s.balance(a.id), 1200000);
  assert.equal(s.debtRemaining(d.id), 300000);
  assert.equal(s.state.transactions.at(-1).type, 'income');
  assert.equal(s.state.transactions.at(-1).debtId, d.id);
  s.addDebtPayment({ debtId: d.id, amount: 300000 });          // paid in cash outside the app: no ledger entry
  assert.equal(s.balance(a.id), 1200000);
  assert.equal(s.state.debts[0].closed, true);
});

test('debt I owe: payment becomes expense; overpay and currency mismatch rejected', () => {
  const { s, a } = fresh();
  const d = s.addDebt({ kind: 'i_owe', person: 'بنك', amount: 400000 });
  s.addDebtPayment({ debtId: d.id, amount: 100000, accountId: a.id });
  assert.equal(s.balance(a.id), 900000);
  assert.equal(s.state.transactions.at(-1).type, 'expense');
  assert.throws(() => s.addDebtPayment({ debtId: d.id, amount: 300001 }), /exceeds/);
  const u = s.addAccount({ name: 'USD', currency: 'USD', opening: 10000 });
  assert.throws(() => s.addDebtPayment({ debtId: d.id, amount: 1000, accountId: u.id }), /currency/);
  assert.equal(s.debtRemaining(d.id), 300000);                  // failed payments change nothing
  assert.throws(() => s.addDebt({ kind: 'x', person: 'a', amount: 5 }));
  assert.throws(() => s.addDebt({ kind: 'i_owe', person: ' ', amount: 5 }));
});

test('budgets: spent counts only this month and this category, converts currencies', () => {
  const { s, a } = fresh();
  const food = cat(s, 'expense', 'طعام'), fuel = cat(s, 'expense', 'مواصلات');
  s.setBudget(food, 100000);
  s.addTransaction({ type: 'expense', accountId: a.id, categoryId: food, amount: 30000, ts: '2026-11-05T10:00:00' });
  s.addTransaction({ type: 'expense', accountId: a.id, categoryId: fuel, amount: 99999, ts: '2026-11-06T10:00:00' });
  s.addTransaction({ type: 'expense', accountId: a.id, categoryId: food, amount: 70000, ts: '2026-10-30T10:00:00' });   // other month
  let st = s.budgetStatus('2026-11')[0];
  assert.deepEqual([st.spent, st.remaining, st.pct, st.over], [30000, 70000, 30, false]);
  const u = s.addAccount({ name: 'USD', currency: 'USD', opening: 100000 });
  s.addTransaction({ type: 'expense', accountId: u.id, categoryId: food, amount: 1000, ts: '2026-11-07T10:00:00' });    // 10 USD, no rate yet
  assert.equal(s.budgetStatus('2026-11')[0].unconverted, 1);
  s.setRate('USD', 4);
  st = s.budgetStatus('2026-11')[0];
  assert.deepEqual([st.spent, st.pct, st.unconverted], [70000, 70, 0]);               // 30.000 + 10*4
  s.setBudget(food, 50000);                                                           // upsert, not duplicate
  assert.equal(s.state.budgets.length, 1);
  assert.equal(s.budgetStatus('2026-11')[0].over, true);
  assert.throws(() => s.setBudget(cat(s, 'income', 'مرتب'), 5));
  s.removeBudget(food); assert.equal(s.state.budgets.length, 0);
});

test('goals: progress accumulates, caps at 100, flags done', () => {
  const { s } = fresh();
  const g = s.addGoal({ name: 'سيارة', target: 1000000 });
  s.contribute(g.id, 250000); assert.deepEqual(s.goalProgress(g.id), { saved: 250000, target: 1000000, pct: 25, done: false });
  s.contribute(g.id, 900000); const p = s.goalProgress(g.id);
  assert.equal(p.pct, 100); assert.equal(p.done, true);
  assert.throws(() => s.contribute(g.id, -5)); assert.throws(() => s.addGoal({ name: '', target: 5 }));
});

test('reminders: due ones alert; repeating ones roll forward; one-off ones finish', () => {
  const { s } = fresh();
  const once = s.addReminder({ title: 'إيجار', due: '2026-11-10T09:00:00Z' });
  const rep = s.addReminder({ title: 'فاتورة', due: '2026-11-10T09:00:00Z', repeat: 'monthly' });
  s.addReminder({ title: 'لاحقاً', due: '2027-01-01T09:00:00Z' });
  const now = new Date('2026-11-18T12:00:00Z');
  assert.equal(s.alerts(now).filter(a => a.kind === 'reminder').length, 2);
  s.completeReminder(once.id); s.completeReminder(rep.id);
  const left = s.alerts(now).filter(a => a.kind === 'reminder');
  assert.equal(left.length, 0);
  assert.equal(s.state.reminders.find(r => r.id === rep.id).due.slice(0, 10), '2026-12-10');
  assert.equal(s.state.reminders.find(r => r.id === once.id).done, true);
  assert.throws(() => s.addReminder({ title: 'x', due: 'nope' }));
});

test('alerts: debt due soon/overdue and budgets near/over limit', () => {
  const { s, a } = fresh();
  const food = cat(s, 'expense', 'طعام');
  const now = new Date('2026-11-18T12:00:00');
  s.addDebt({ kind: 'owed_to_me', person: 'A', amount: 5, dueDate: '2026-11-17' });   // overdue
  s.addDebt({ kind: 'i_owe', person: 'B', amount: 5, dueDate: '2026-11-20' });         // in 2 days
  s.addDebt({ kind: 'i_owe', person: 'C', amount: 5, dueDate: '2026-12-30' });         // far away
  s.setBudget(food, 100000);
  s.addTransaction({ type: 'expense', accountId: a.id, categoryId: food, amount: 85000, ts: '2026-11-10T10:00:00' });
  const al = s.alerts(now);
  const debts = al.filter(x => x.kind === 'debt');
  assert.deepEqual(debts.map(x => [x.person, x.overdue]).sort(), [['A', true], ['B', false]]);
  assert.equal(al.filter(x => x.kind === 'budget')[0].pct, 85);
});

test('backup from an older version (no new arrays) loads safely; all new data round-trips', () => {
  const { s, a } = fresh();
  s.addDebt({ kind: 'i_owe', person: 'X', amount: 10 }); s.addGoal({ name: 'g', target: 10 }); s.addReminder({ title: 'r', due: '2026-12-01T00:00:00Z' });
  const dump = s.exportBackup();
  const s2 = MM.createStore(mem()); s2.importBackup(dump);
  assert.equal(s2.state.debts.length, 1); assert.equal(s2.state.goals.length, 1); assert.equal(s2.state.reminders.length, 1);
  const old = JSON.parse(dump); delete old.data.debts; delete old.data.budgets; delete old.data.goals; delete old.data.reminders;
  const s3 = MM.createStore(mem()); s3.importBackup(JSON.stringify(old));
  assert.deepEqual([s3.state.debts, s3.state.budgets, s3.state.goals, s3.state.reminders], [[], [], [], []]);
  assert.doesNotThrow(() => s3.alerts());
});

test('deleting the transaction of a debt payment reopens the debt', () => {
  const { s, a } = fresh();
  const d = s.addDebt({ kind: 'owed_to_me', person: 'Z', amount: 100000 });
  s.addDebtPayment({ debtId: d.id, amount: 100000, accountId: a.id });
  assert.equal(s.state.debts[0].closed, true);
  s.deleteTransaction(s.state.transactions.at(-1).id);
  assert.equal(s.debtRemaining(d.id), 100000); assert.equal(s.state.debts[0].closed, false);
  assert.equal(s.balance(a.id), 1000000);
});
