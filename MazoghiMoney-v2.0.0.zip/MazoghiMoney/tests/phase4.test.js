const test = require('node:test'), assert = require('node:assert/strict');
const MM = require('../app/src/main/assets/www/js/engine.js');
const mem = () => { const m = {}; return { get: k => (k in m ? m[k] : null), set: (k, v) => { m[k] = v; } }; };
const cat = (s, kind, ar) => s.state.categories.find(c => c.kind === kind && c.ar === ar).id;

function seeded() {
  const s = MM.createStore(mem()); const a = s.addAccount({ name: 'Cash', opening: 1000000 }), u = s.addAccount({ name: 'USD', currency: 'USD', opening: 50000 });
  s.setRate('USD', 4);
  const food = cat(s, 'expense', 'طعام'), bills = cat(s, 'expense', 'فواتير'), sal = cat(s, 'income', 'مرتب');
  s.addTransaction({ type: 'income', accountId: a.id, categoryId: sal, amount: 2000000, ts: '2026-10-01T10:00:00' });
  s.addTransaction({ type: 'expense', accountId: a.id, categoryId: food, amount: 300000, ts: '2026-10-05T10:00:00' });
  s.addTransaction({ type: 'expense', accountId: a.id, categoryId: bills, amount: 100000, ts: '2026-11-02T10:00:00' });
  s.addTransaction({ type: 'expense', accountId: u.id, categoryId: food, amount: 5000, ts: '2026-11-03T10:00:00' });   // 50 USD = 200 LYD
  s.addTransfer({ fromId: a.id, toId: u.id, amount: 400000, ts: '2026-11-04T10:00:00' });
  return { s, a, u, food, bills, sal };
}

test('report: totals, categories, months; transfers ignored; USD converted', () => {
  const { s, food, bills } = seeded(); const r = s.report();
  assert.equal(r.income, 2000000); assert.equal(r.expense, 300000 + 100000 + 200000); assert.equal(r.net, 2000000 - 600000);
  assert.deepEqual(r.byCategory.map(c => [c.categoryId, c.total, c.pct]), [[food, 500000, 83], [bills, 100000, 17]]);
  assert.deepEqual(r.byMonth.map(m => [m.month, m.income, m.expense]), [['2026-10', 2000000, 300000], ['2026-11', 0, 300000]]);
  assert.equal(r.accounts.length, 2); assert.equal(r.unconverted, 0);
});

test('report: date range is inclusive; missing rate is counted, not guessed', () => {
  const { s } = seeded();
  const nov = s.report({ from: '2026-11-01', to: '2026-11-30' }); assert.equal(nov.income, 0); assert.equal(nov.expense, 300000);
  const day = s.report({ from: '2026-11-03', to: '2026-11-03' }); assert.equal(day.expense, 200000);
  delete s.state.rates.USD;
  const r = s.report(); assert.equal(r.unconverted, 1); assert.equal(r.expense, 400000);
});

test('report: open debts summarised in base currency', () => {
  const { s } = seeded();
  s.addDebt({ kind: 'owed_to_me', person: 'A', amount: 700000 }); const d = s.addDebt({ kind: 'i_owe', person: 'B', amount: 100000 });
  s.addDebtPayment({ debtId: d.id, amount: 100000 });
  assert.deepEqual(s.report().debts, { owedToMe: 700000, iOwe: 0 });
});

test('encrypted backup: round trip, wrong password rejected, no plaintext leak', async () => {
  const { s } = seeded(); const plain = s.exportBackup();
  const enc = await MM.encryptBackup(plain, 'سر قوي 123');
  assert.equal(MM.isEncryptedBackup(enc), true); assert.equal(MM.isEncryptedBackup(plain), false);
  assert.equal(enc.includes('Cash'), false);
  assert.equal(await MM.decryptBackup(enc, 'سر قوي 123'), plain);
  await assert.rejects(MM.decryptBackup(enc, 'wrong'), /Wrong password/);
  const tampered = JSON.parse(enc); tampered.data = tampered.data.slice(0, -4) + 'AAAA';
  await assert.rejects(MM.decryptBackup(JSON.stringify(tampered), 'سر قوي 123'), /Wrong password or corrupted/);
  await assert.rejects(MM.encryptBackup(plain, ''), /Password/);
  const s2 = MM.createStore(mem()); s2.importBackup(await MM.decryptBackup(enc, 'سر قوي 123')); assert.equal(s2.state.transactions.length, s.state.transactions.length);
});

test('notification plan: future reminders, repeats, debt due at 09:00; past and finished ones skipped', () => {
  const { s } = seeded(); const now = new Date('2026-11-18T12:00:00');
  s.addReminder({ title: 'past', due: '2026-11-01T09:00:00' });
  const rep = s.addReminder({ title: 'rent', due: '2026-11-20T09:00:00', repeat: 'monthly' });
  const fin = s.addReminder({ title: 'done', due: '2026-11-25T09:00:00' }); s.completeReminder(fin.id);
  s.addDebt({ kind: 'i_owe', person: 'B', amount: 5, dueDate: '2026-11-19' }); s.addDebt({ kind: 'i_owe', person: 'old', amount: 5, dueDate: '2026-11-01' });
  const p = s.notificationPlan(now);
  assert.deepEqual(p.map(x => x.kind + ':' + (x.title || x.person)), ['debt:B', 'reminder:rent', 'reminder:rent', 'reminder:rent']);
  assert.equal(new Date(p[0].at).getHours(), 9); assert.equal(new Set(p.map(x => x.key)).size, p.length);
});

test('transactionsIn: inclusive range, sorted by time, includes transfers', () => {
  const { s } = seeded();
  const all = s.transactionsIn(); assert.equal(all.length, 5); assert.deepEqual(all.map(x => x.ts.slice(0, 10)), ['2026-10-01', '2026-10-05', '2026-11-02', '2026-11-03', '2026-11-04']);
  const nov = s.transactionsIn({ from: '2026-11-03', to: '2026-11-04' }); assert.deepEqual(nov.map(x => x.type), ['expense', 'transfer']);
});
