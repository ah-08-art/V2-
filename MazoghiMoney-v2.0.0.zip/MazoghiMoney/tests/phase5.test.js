const test = require('node:test'), assert = require('node:assert/strict');
const MM = require('../app/src/main/assets/www/js/engine.js'), Sync = require('../app/src/main/assets/www/js/sync.js');
const mem = () => { const m = {}; return { get: k => (k in m ? m[k] : null), set: (k, v) => { m[k] = v; }, m }; };

test('limits: amount cap, text length, invalid dates and opening balance rejected', () => {
  const s = MM.createStore(mem()); const a = s.addAccount({ name: 'A' });
  assert.throws(() => s.addTransaction({ type: 'income', accountId: a.id, amount: 1e13 + 1 }), /too large/);
  assert.doesNotThrow(() => s.addTransaction({ type: 'income', accountId: a.id, amount: 1e13 }));
  assert.throws(() => s.addTransaction({ type: 'income', accountId: a.id, amount: 5, title: 'x'.repeat(121) }), /too long/);
  assert.throws(() => s.addTransaction({ type: 'income', accountId: a.id, amount: 5, note: 'x'.repeat(501) }), /too long/);
  assert.throws(() => s.addTransaction({ type: 'income', accountId: a.id, amount: 5, ts: 'garbage' }), /Invalid date/);
  assert.throws(() => s.addAccount({ name: 'x'.repeat(61) }), /too long/);
  assert.throws(() => s.addAccount({ name: 'ok', opening: 1.5 }), /opening/);
  assert.throws(() => s.addAccount({ name: 'ok', opening: 1e14 }), /opening/);
  assert.throws(() => s.addDebt({ kind: 'i_owe', person: 'p', amount: 5, dueDate: 'zzz' }), /Invalid date/);
  assert.throws(() => s.addGoal({ name: 'g', target: 5, deadline: 'zzz' }), /Invalid date/);
  assert.equal(s.state.transactions.length, 1);                       // nothing partial was added by the failures
});

test('PIN throttling: 5 failures lock for 30s, doubling; success resets; lock survives restart', async () => {
  const ad = mem(); const s = await MM.open(ad); const h = await MM.hashPin('1234'); s.state.settings.pinHash = h.hash; s.state.settings.pinSalt = h.salt; s.save();
  const st = s.state; let now = 1e12;
  for (let i = 0; i < 4; i++) { const r = await MM.tryPin('0000', st, now); assert.equal(r.ok, false); assert.equal(r.waitMs, 0); }
  const r5 = await MM.tryPin('0000', st, now); assert.equal(r5.waitMs, 30000);
  const locked = await MM.tryPin('1234', st, now + 1000);               // correct PIN is refused while locked
  assert.deepEqual([locked.ok, locked.waitMs], [false, 29000]);
  now += 31000; for (let i = 0; i < 4; i++) await MM.tryPin('0000', st, now);
  assert.equal((await MM.tryPin('0000', st, now)).waitMs, 60000);        // 10th failure -> 60s
  s.save(); const s2 = await MM.open(ad); assert.ok(MM.lockWait(s2.state, now + 1000) > 0);   // persisted
  now += 61000; const ok = await MM.tryPin('1234', s2.state, now); assert.equal(ok.ok, true); assert.equal(s2.state.settings.fails, 0);
  assert.equal((await MM.tryPin('anything', { settings: {} })).ok, true);   // no PIN set -> no check
});

test('corrupt main file: recovered from the daily snapshot, corrupt copy kept aside', async () => {
  const ad = mem(); const s = await MM.open(ad); const a = s.addAccount({ name: 'Cash', opening: 5000 });
  ad.set('mm_snapshot_at', '1');                                         // a day has passed: the next save refreshes the snapshot
  s.addTransaction({ type: 'income', accountId: a.id, amount: 700 });    // snapshot now = state before this transaction (account exists)
  s.addTransaction({ type: 'income', accountId: a.id, amount: 800 });    // after the snapshot: this is the part a corrupt-file recovery can lose
  ad.set('mm_state_v2', '{"schema":2,"accounts":[');                     // truncated write
  const r = await MM.open(ad); assert.equal(r.recovered, true); assert.equal(r.state.accounts.length, 1);
  assert.equal(r.balance(r.state.accounts[0].id), 5000);                 // restored to the snapshot, documented loss of up to a day
  assert.equal(ad.get('mm_corrupt'), '{"schema":2,"accounts":[');
  const again = await MM.open(ad); assert.equal(again.state.accounts.length, 1);   // repaired file loads normally
});

test('corrupt file with no snapshot fails loudly instead of starting empty', async () => {
  const ad = mem(); ad.set('mm_state_v2', 'not json');
  await assert.rejects(MM.open(ad));
  assert.equal(ad.get('mm_state_v2'), 'not json');                       // untouched
});

test('snapshot is refreshed at most once a day', async () => {
  const ad = mem(); const s = await MM.open(ad); const a = s.addAccount({ name: 'A' });
  const first = ad.get('mm_snapshot_at'); s.addTransaction({ type: 'income', accountId: a.id, amount: 5 }); s.addTransaction({ type: 'income', accountId: a.id, amount: 6 });
  assert.equal(ad.get('mm_snapshot_at'), first);
});

test('audit log is capped, newest entries kept', () => {
  const s = MM.createStore(mem()); const a = s.addAccount({ name: 'A' });
  for (let i = 0; i < 5100; i++) s.state.transactions.length < 0 || s.addTransaction({ type: 'income', accountId: a.id, amount: 1 });
  assert.equal(s.state.log.length, 5000); assert.equal(s.state.transactions.length, 5100); assert.equal(s.balance(a.id), 5100);
});

test('sync: first push, no-op, local push, remote pull, conflict never overwrites', async () => {
  const prov = Sync.memoryProvider(), A = MM.createStore(mem()), B = MM.createStore(mem());
  const a = A.addAccount({ name: 'Cash', opening: 1000 });
  assert.equal((await Sync.run(A, prov, 'pw')).status, 'pushed');
  assert.equal((await Sync.run(A, prov, 'pw')).status, 'up-to-date');
  assert.equal((await Sync.run(B, prov, 'pw')).status, 'pulled'); assert.equal(B.state.accounts.length, 1);   // second device receives data
  A.addTransaction({ type: 'income', accountId: a.id, amount: 500 });
  assert.equal((await Sync.run(A, prov, 'pw')).status, 'pushed');
  assert.equal((await Sync.run(B, prov, 'pw')).status, 'pulled'); assert.equal(B.balance(B.state.accounts[0].id), 1500);
  A.addTransaction({ type: 'expense', accountId: a.id, amount: 100 }); B.addTransaction({ type: 'expense', accountId: B.state.accounts[0].id, amount: 300 });
  assert.equal((await Sync.run(A, prov, 'pw')).status, 'pushed');
  const before = JSON.stringify(B.state);
  const c = await Sync.run(B, prov, 'pw'); assert.equal(c.status, 'conflict'); assert.equal(JSON.stringify(B.state), before);   // untouched
  assert.equal((await Sync.resolve(B, prov, 'pw', 'remote')).status, 'pulled'); assert.equal(B.balance(B.state.accounts[0].id), 1400);
});

test('sync: wrong password changes nothing; provider only sees ciphertext; local-wins resolves a conflict', async () => {
  const prov = Sync.memoryProvider(), A = MM.createStore(mem()), B = MM.createStore(mem());
  A.addAccount({ name: 'SecretName', opening: 1 }); await Sync.run(A, prov, 'pw');
  assert.equal((await prov.pull()).blob.includes('SecretName'), false);
  await assert.rejects(Sync.run(B, prov, 'nope'), /Wrong password/); assert.equal(B.state.accounts.length, 0);
  await Sync.run(B, prov, 'pw'); A.addAccount({ name: 'A2' }); B.addAccount({ name: 'B2' }); await Sync.run(A, prov, 'pw');
  assert.equal((await Sync.run(B, prov, 'pw')).status, 'conflict');
  assert.equal((await Sync.resolve(B, prov, 'pw', 'local')).status, 'pushed'); assert.equal((await Sync.run(A, prov, 'pw')).status, 'pulled'); assert.ok(A.state.accounts.some(x => x.name === 'B2'));
  await assert.rejects(Sync.run(A, prov, ''), /password required/);
});

test('sync: a restored backup file never claims to be in sync', async () => {
  const prov = Sync.memoryProvider(), A = MM.createStore(mem()); A.addAccount({ name: 'x' }); await Sync.run(A, prov, 'pw');
  const dump = A.exportBackup(); const B = MM.createStore(mem()); B.importBackup(dump);
  assert.equal(B.state.sync, undefined); assert.equal((await Sync.run(B, prov, 'pw')).status, 'conflict');   // asks the user instead of guessing
});

test('sync: changes in the same millisecond are still detected', async () => {
  const prov = Sync.memoryProvider(), A = MM.createStore(mem()), B = MM.createStore(mem()); const a = A.addAccount({ name: 'x', opening: 10 });
  await Sync.run(A, prov, 'pw'); await Sync.run(B, prov, 'pw');
  const realNow = Date.now, fixed = realNow(); Date.now = () => fixed; const RealDate = Date;
  try { A.addTransaction({ type: 'income', accountId: a.id, amount: 1 }); B.addTransaction({ type: 'income', accountId: B.state.accounts[0].id, amount: 2 }); } finally { Date.now = realNow; }
  assert.equal((await Sync.run(A, prov, 'pw')).status, 'pushed'); assert.equal((await Sync.run(B, prov, 'pw')).status, 'conflict');
});

test('missing data file after initialisation is never replaced by an empty state', async () => {
  const ad = mem(); const s = await MM.open(ad); s.addAccount({ name: 'Cash', opening: 900 });
  assert.equal(ad.get('mm_initialized'), '1');
  const saved = ad.get('mm_state_v2'); delete ad.m['mm_state_v2']; delete ad.m['mm_snapshot'];   // e.g. a transient failed read, no snapshot yet
  await assert.rejects(MM.open(ad), /missing/);
  assert.equal(ad.get('mm_state_v2'), null);                                            // nothing was written over it
  ad.set('mm_snapshot', saved); const r = await MM.open(ad);                            // with a snapshot it recovers instead
  assert.equal(r.recovered, true); assert.equal(r.state.accounts.length, 1);
});

test('installs from before the marker get it on first load; a genuinely fresh install still starts empty', async () => {
  const ad = mem(); const s = await MM.open(ad); s.addAccount({ name: 'A' }); delete ad.m['mm_initialized'];
  const again = await MM.open(ad); assert.equal(again.state.accounts.length, 1); assert.equal(ad.get('mm_initialized'), '1');
  const fresh = await MM.open(mem()); assert.equal(fresh.state.accounts.length, 0);
});
