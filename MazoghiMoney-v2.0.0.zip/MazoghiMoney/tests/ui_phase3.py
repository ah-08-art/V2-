import sys, datetime
from playwright.sync_api import sync_playwright
URL = 'file:///home/claude/mazoghi-money/app/src/main/assets/www/index.html'
MOCK = "(function(){function L(){try{return JSON.parse(window.name||'{}')}catch(e){return {}}}window.NativeStore={get:function(k){var o=L();return k in o?o[k]:null},set:function(k,v){var o=L();o[k]=v;window.name=JSON.stringify(o);return true}};})();"
res = []
def ok(name, cond): res.append(bool(cond)); print(('PASS ' if cond else 'FAIL ') + name)
now = datetime.datetime.now(); yday = (now - datetime.timedelta(days=1)).strftime('%Y-%m-%d'); hour_ago = (now - datetime.timedelta(hours=1)).strftime('%Y-%m-%dT%H:%M')
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 390, 'height': 800}).new_page()
    errs, reqs, dlg = [], [], []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('request', lambda r: reqs.append(r.url) if not r.url.startswith('file:') else None)
    pg.on('dialog', lambda d: (dlg.append(d.message), d.accept()))
    pg.add_init_script(MOCK); pg.goto(URL); pg.wait_for_selector('.hero')
    go = lambda v: (pg.click(f'nav [data-go={v}]'), pg.wait_for_timeout(120))
    total = lambda: pg.inner_text('.hero .big')
    go('accounts'); pg.fill('#a-name', 'Cash'); pg.fill('#a-open', '1000'); pg.click('#a-save'); pg.wait_for_timeout(150)
    # debts
    go('plan'); pg.click('[data-newdebt]'); pg.select_option('#f_kind', 'owed_to_me'); pg.fill('#f_person', '<img src=x onerror=window.__x=1>أحمد'); pg.fill('#f_amount', '500'); pg.fill('#f_due', yday); pg.click('#form-save'); pg.wait_for_timeout(200)
    ok('debt listed with remaining 500.000', '500.000' in pg.inner_text('#app'))
    ok('person name escaped (no injected element)', pg.locator('#app img').count() == 0 and pg.evaluate('window.__x') is None)
    pg.click('[data-paydebt]'); pg.fill('#f_amount', '999'); pg.click('#form-save'); pg.wait_for_timeout(200)
    ok('overpayment rejected with a clear in-app message', 'أكبر من المتبقي' in pg.inner_text('#toast')); pg.click('#s-cancel')
    pg.click('[data-paydebt]'); pg.fill('#f_amount', '200'); pg.select_option('#f_acc', index=1); pg.click('#form-save'); pg.wait_for_timeout(200)
    ok('payment lowers remaining to 300.000', '300.000' in pg.inner_text('#app'))
    go('home'); ok('payment credited to account (1,200.000)', '1,200.000' in total())
    ok('overdue debt alert on home', 'متأخر' in pg.inner_text('.alerts'))
    # budget
    go('plan'); pg.click('[data-plan=budgets]'); pg.click('[data-newbudget]'); pg.fill('#f_limit', '100'); pg.click('#form-save'); pg.wait_for_timeout(150)
    pg.click('nav .plus'); pg.fill('#s-amt', '85'); pg.click('#s-save'); pg.wait_for_timeout(200)
    go('plan'); pg.click('[data-plan=budgets]'); txt = pg.inner_text('#app')
    ok('budget shows 85.000 spent of 100.000', '85.000' in txt and '100.000' in txt)
    go('home'); ok('budget 85% alert on home', '85%' in pg.inner_text('.alerts'))
    # goals
    go('plan'); pg.click('[data-plan=goals]'); pg.click('[data-newgoal]'); pg.fill('#f_name', 'سيارة'); pg.fill('#f_target', '1000'); pg.click('#form-save'); pg.wait_for_timeout(150)
    pg.click('[data-contrib]'); pg.fill('#f_amount', '250'); pg.click('#form-save'); pg.wait_for_timeout(150)
    ok('goal at 25%', '25%' in pg.inner_text('#app'))
    # reminders
    pg.click('[data-plan=reminders]'); pg.click('[data-newrem]'); pg.fill('#f_title', 'إيجار'); pg.fill('#f_due', hour_ago); pg.click('#form-save'); pg.wait_for_timeout(150)
    go('home'); ok('due reminder alert on home', '🔔' in pg.inner_text('.alerts'))
    go('plan'); pg.click('[data-plan=reminders]'); pg.click('[data-remdone]'); pg.wait_for_timeout(150)
    go('home'); ok('completed reminder no longer alerts', '🔔' not in pg.inner_text('.alerts'))
    # persistence + English
    pg.reload(); pg.wait_for_selector('.hero'); go('plan'); ok('debts persist after reload', '300.000' in pg.inner_text('#app'))
    go('settings'); pg.click('[data-lang=en]'); go('plan'); pg.click('[data-plan=goals]')
    ok('English labels in Plan', 'New goal' in pg.inner_text('#app') and pg.evaluate('document.documentElement.dir') == 'ltr')
    # delete the payment's transaction -> debt reopens with 500
    go('history'); pg.click('[data-del]:nth-of-type(1)') if False else None
    items = pg.locator('.item', has_text='+200.000'); ok('payment appears in history as income', items.count() == 1)
    items.locator('[data-del]').click(); pg.click('#ask-yes'); pg.wait_for_timeout(200); go('plan'); pg.click('[data-plan=debts]')
    ok('deleting that transaction reopens the debt (500.000)', '500.000' in pg.inner_text('#app'))
    ok('no blocking browser dialogs used', not dlg)
    ok('no JS errors', not errs); ok('zero network requests', not reqs)
    if errs: print(errs)
    pg.screenshot(path='/home/claude/shot_plan.png'); b.close()
sys.exit(0 if all(res) else 1)
