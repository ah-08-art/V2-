import sys, json, os, subprocess, tempfile
from playwright.sync_api import sync_playwright
import openpyxl
URL = 'file:///home/claude/mazoghi-money/app/src/main/assets/www/index.html'
STORE = "(function(){function L(){try{return JSON.parse(window.name||'{}')}catch(e){return {}}}window.NativeStore={get:function(k){var o=L();return k in o?o[k]:null},set:function(k,v){var o=L();o[k]=v;window.name=JSON.stringify(o);return true}};})();"
BRIDGE = """window.__calls=[];window.NativeBridge={capabilities:function(){return JSON.stringify({biometric:true,files:true,print:true,notifications:true})},
 saveFile:function(n,m,b){__calls.push(['save',n,m,b.length]);setTimeout(function(){window.__onFileSaved(true)},10)},pickFile:function(){__calls.push(['pick'])},
 printPage:function(t){__calls.push(['print',t])},authenticate:function(t,c){__calls.push(['auth']);setTimeout(function(){window.__onBiometric(window.__bioResult!==false)},10)},
 scheduleNotifications:function(j){__calls.push(['sched',j])}};"""
res = []
def ok(name, cond): res.append(bool(cond)); print(('PASS ' if cond else 'FAIL ') + name)
tmp = tempfile.mkdtemp()
def page(b, bridge=False):
    ctx = b.new_context(viewport={'width': 390, 'height': 800}, accept_downloads=True); pg = ctx.new_page()
    pg.errs, pg.reqs, pg.dlg = [], [], []
    pg.on('pageerror', lambda e: pg.errs.append(str(e))); pg.on('request', lambda r: pg.reqs.append(r.url) if not r.url.startswith(('file:', 'blob:')) else None)
    pg.on('dialog', lambda d: (pg.dlg.append(d.message), d.accept()))
    pg.add_init_script(STORE)
    if bridge: pg.add_init_script(BRIDGE)
    pg.goto(URL); pg.wait_for_selector('.hero'); return pg
def go(pg, v): pg.click(f'nav [data-go={v}]'); pg.wait_for_timeout(120)
def plan_tab(pg, k): go(pg, 'plan'); pg.click(f'[data-plan={k}]'); pg.wait_for_timeout(120)
def seed(pg):
    go(pg, 'accounts'); pg.fill('#a-name', 'Cash'); pg.fill('#a-open', '1000'); pg.click('#a-save'); pg.wait_for_timeout(120)
    pg.click('nav .plus'); pg.click('[data-type=income]'); pg.fill('#s-amt', '2000'); pg.click('#s-save'); pg.wait_for_timeout(120)
    pg.click('nav .plus'); pg.fill('#s-amt', '300'); pg.click('#s-save'); pg.wait_for_timeout(120)
    pg.click('nav .plus'); pg.select_option('#s-cat', label='فواتير'); pg.fill('#s-amt', '100'); pg.click('#s-save'); pg.wait_for_timeout(120)

with sync_playwright() as p:
    b = p.chromium.launch()
    # ---------- browser fallback ----------
    pg = page(b); seed(pg); plan_tab(pg, 'reports')
    ok('report net = 2000 - 400 = 1,600.000', '1,600.000' in pg.inner_text('#rep-net'))
    ok('categories sorted with share (food 75%, bills 25%)', '75%' in pg.inner_text('#rep-cats') and '25%' in pg.inner_text('#rep-cats') and pg.inner_text('#rep-cats').index('طعام') < pg.inner_text('#rep-cats').index('فواتير'))
    ok('percentages are bidi-isolated (no scrambled "%" in Arabic text)', pg.locator('#rep-cats bdi[dir=ltr]').count() == 2)
    ok('monthly trend chart drawn', pg.locator('#rep-trend svg rect').count() == 2)
    pg.select_option('#rep-period', 'last'); pg.wait_for_timeout(150)
    ok('last month is empty (no data leaks across periods)', '0.000' in pg.inner_text('#rep-net') and pg.locator('#rep-trend svg').count() == 0)
    pg.select_option('#rep-period', 'month'); pg.wait_for_timeout(150)
    with pg.expect_download() as d: pg.click('#rep-xlsx')
    x = os.path.join(tmp, 'r.xlsx'); d.value.save_as(x); wb = openpyxl.load_workbook(x)
    ok('xlsx has 4 sheets incl. العمليات', len(wb.sheetnames) == 4 and 'العمليات' in wb.sheetnames)
    tx = wb['العمليات']; amts = [r[6].value for r in tx.iter_rows(min_row=2)]
    ok('xlsx transactions numeric and sum to net 1600', len(amts) == 3 and all(isinstance(a, (int, float)) for a in amts) and abs(sum(amts) - 1600) < 1e-9)
    ok('xlsx summary net + RTL sheet', wb['ملخص']['B4'].value == 1600 and tx.sheet_view.rightToLeft is True)
    ok('xlsx accounts sheet balance 2,600', wb['الحسابات']['C2'].value == 2600)
    pg.evaluate("window.print=function(){window.__printed=true}"); pg.click('#rep-pdf'); pg.wait_for_timeout(150)
    ok('print invoked with report content', pg.evaluate('window.__printed') is True and '1,600.000' in pg.inner_text('#print') and pg.locator('#print tr').count() > 8)
    pdf = os.path.join(tmp, 'ar.pdf'); pg.pdf(path=pdf); txt = subprocess.run(['pdftotext', '-layout', pdf, '-'], capture_output=True, text=True).stdout
    ok('PDF (Arabic) contains figures and Arabic text, hides the app UI', '1,600.000' in txt and any('\u0600' <= c <= '\u06ff' or '\ufe70' <= c <= '\ufeff' for c in txt) and 'Plan' not in txt)
    go(pg, 'settings'); pg.click('[data-lang=en]'); plan_tab(pg, 'reports'); pg.evaluate("window.print=function(){}"); pg.click('#rep-pdf')
    pdf2 = os.path.join(tmp, 'en.pdf'); pg.pdf(path=pdf2); txt2 = subprocess.run(['pdftotext', '-layout', pdf2, '-'], capture_output=True, text=True).stdout
    ok('PDF (English) has title, net, category and transactions', 'Reports' in txt2 and '1,600.000 LYD' in txt2 and 'Food' in txt2 and 'Bills' in txt2 and 'Income' in txt2)
    import shutil; shutil.copy(pdf, '/home/claude/report_ar.pdf')
    go(pg, 'settings'); pg.click('[data-lang=ar]')
    # backups
    go(pg, 'settings')
    with pg.expect_download() as d: pg.click('#bk-export')
    f1 = os.path.join(tmp, 'plain.json'); d.value.save_as(f1); j = json.load(open(f1))
    ok('plain backup file is valid and complete', j['app'] == 'mazoghi-money' and len(j['data']['transactions']) == 3)
    pg.fill('#bk-pass', 'pw123')
    with pg.expect_download() as d: pg.click('#bk-export')
    f2 = os.path.join(tmp, 'enc.json'); d.value.save_as(f2); raw = open(f2, encoding='utf-8').read()
    ok('encrypted backup hides all data', json.loads(raw)['app'] == 'mazoghi-money-enc' and 'Cash' not in raw and d.value.suggested_filename.endswith('.enc.json'))
    go(pg, 'accounts'); pg.click('nav .plus'); pg.fill('#s-amt', '50'); pg.click('#s-save'); pg.wait_for_timeout(150)
    go(pg, 'settings'); pg.set_input_files('#bk-file', f2); pg.wait_for_selector('#ask-in'); pg.fill('#ask-in', 'bad'); pg.click('#ask-ok'); pg.wait_for_timeout(300)
    ok('wrong password rejected, data untouched', 'غير صحيحة' in pg.inner_text('#toast') and len(json.loads(pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)"))['transactions']) == 4)
    pg.set_input_files('#bk-file', f2); pg.wait_for_selector('#ask-in'); pg.fill('#ask-in', 'pw123'); pg.click('#ask-ok'); pg.wait_for_selector('#ask-yes'); pg.click('#ask-yes'); pg.wait_for_timeout(300)
    ok('restore with right password returns to 3 transactions', len(json.loads(pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)"))['transactions']) == 3)
    pg.fill('#bk-text', 'not json'); pg.click('#bk-import'); pg.wait_for_timeout(200); ok('garbage backup rejected with message', 'غير صالح' in pg.inner_text('#toast'))
    ok('browser path: no JS errors, no network, no native dialogs', not pg.errs and not pg.reqs and not pg.dlg)
    if pg.errs: print(pg.errs)

    # ---------- native bridge (mocked) ----------
    pg = page(b, bridge=True); seed(pg)
    calls = lambda k: [c for c in pg.evaluate('window.__calls') if c[0] == k]
    ok('notifications synced on start', len(calls('sched')) >= 1)
    go(pg, 'settings'); ok('no fingerprint button without a PIN', pg.locator('#bio-toggle').count() == 0)
    pg.fill('#pin-new', '1234'); pg.click('#pin-save'); pg.wait_for_timeout(300)
    ok('fingerprint button appears once a PIN exists', pg.locator('#bio-toggle').count() == 1)
    pg.click('#bio-toggle'); pg.wait_for_timeout(300); ok('fingerprint enabled after a successful prompt', len(calls('auth')) == 1 and 'إيقاف' in pg.inner_text('#bio-toggle'))
    pg.click('#lock-now'); pg.wait_for_timeout(300); ok('lock screen auto-unlocks via fingerprint', len(calls('auth')) == 2 and not pg.is_visible('#lock'))
    pg.evaluate('window.__bioResult=false'); pg.click('#lock-now'); pg.wait_for_timeout(300)
    ok('failed fingerprint keeps the app locked', pg.is_visible('#lock'))
    pg.fill('#lk', '9999'); pg.wait_for_timeout(500); ok('wrong PIN still rejected', pg.is_visible('#lock'))
    pg.fill('#lk', '1234'); pg.wait_for_timeout(500); ok('PIN fallback unlocks', not pg.is_visible('#lock'))
    pg.evaluate('window.__bioResult=true')
    plan_tab(pg, 'reminders'); pg.click('[data-newrem]'); pg.fill('#f_title', 'دفع الإيجار'); pg.fill('#f_due', '2099-01-05T09:00'); pg.click('#form-save'); pg.wait_for_timeout(200)
    last = json.loads(calls('sched')[-1][1]); ok('reminder pushed to the native scheduler', any(x['title'] == 'دفع الإيجار' and x['at'] > 4e12 for x in last))
    plan_tab(pg, 'reports'); pg.click('#rep-xlsx'); pg.wait_for_timeout(200); sv = calls('save')
    ok('xlsx goes through native save with correct name/mime', len(sv) == 1 and sv[0][1].endswith('.xlsx') and 'spreadsheetml' in sv[0][2] and sv[0][3] > 1000 and 'تم حفظ' in pg.inner_text('#toast'))
    pg.click('#rep-pdf'); ok('PDF goes through native print', len(calls('print')) == 1)
    go(pg, 'settings'); pg.click('#bk-pick'); ok('restore uses the native file picker', len(calls('pick')) == 1)
    plain = open(f1, encoding='utf-8').read(); pg.evaluate('t => window.__onFilePicked(t)', plain); pg.wait_for_selector('#ask-yes'); pg.click('#ask-yes'); pg.wait_for_timeout(300)
    ok('native-picked backup restores', len(json.loads(pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)"))['transactions']) == 3)
    ok('bridge path: no JS errors, no network', not pg.errs and not pg.reqs)
    if pg.errs: print(pg.errs)
    b.close()
sys.exit(0 if all(res) else 1)
