import sys, json, subprocess, time
from playwright.sync_api import sync_playwright
URL = 'file:///home/claude/mazoghi-money/app/src/main/assets/www/index.html'
ENGINE = '/home/claude/mazoghi-money/app/src/main/assets/www/js/engine.js'
STORE_JS = "(function(){function L(){try{return JSON.parse(window.name||'{}')}catch(e){return {}}}window.NativeStore={get:function(k){var o=L();return k in o?o[k]:null},set:function(k,v){var o=L();o[k]=v;window.name=JSON.stringify(o);return true}};})();"
res = []
def ok(name, cond): res.append(bool(cond)); print(('PASS ' if cond else 'FAIL ') + name)
def base_state(n):
    st = json.loads(subprocess.run(['node', '-e', f"console.log(JSON.stringify(require('{ENGINE}').emptyState()))"], capture_output=True, text=True).stdout)
    st['accounts'].append({'id': 'acc_main', 'name': 'Cash', 'type': 'cash', 'currency': 'LYD', 'opening': 0, 'archived': False, 'createdAt': '2026-01-01T00:00:00Z'})
    cat = next(c['id'] for c in st['categories'] if c['kind'] == 'expense')
    for i in range(n): st['transactions'].append({'id': f't{i}', 'type': 'expense', 'accountId': 'acc_main', 'categoryId': cat, 'title': f'tx {i}', 'note': '', 'amount': 1000, 'currency': 'LYD', 'ts': f'2026-0{1 + i % 9}-{10 + i % 18}T10:00:00.000Z'})
    return st
def store_js(kv):
    seed = "(function(){if(window.name)return;var o=" + json.dumps(kv) + ";window.name=JSON.stringify(o);})();"
    return STORE_JS + seed
BRIDGE = """window.__calls=[];window.NativeBridge={capabilities:function(){return JSON.stringify({biometric:false,files:true,print:true,notifications:true,secure:true})},
 saveFile:function(){},pickFile:function(){},printPage:function(){},authenticate:function(){},scheduleNotifications:function(){},setSecure:function(on){__calls.push(['secure',on])}};"""
def page(b, kv=None, bridge=False):
    ctx = b.new_context(viewport={'width': 390, 'height': 800}); pg = ctx.new_page(); pg.errs, pg.reqs, pg.dlg = [], [], []
    pg.on('pageerror', lambda e: pg.errs.append(str(e))); pg.on('request', lambda r: pg.reqs.append(r.url) if not r.url.startswith('file:') else None)
    pg.on('dialog', lambda d: (pg.dlg.append(d.message), d.accept()))
    pg.add_init_script(store_js(kv or {}))
    if bridge: pg.add_init_script(BRIDGE)
    pg.goto(URL); pg.wait_for_selector('.hero, #lock:not([hidden]), body > p', state='attached'); pg.wait_for_timeout(300); return pg
def go(pg, v): pg.click(f'nav [data-go={v}]'); pg.wait_for_timeout(100)
def setpin(pg, pin='1234'):
    go(pg, 'settings'); pg.fill('#pin-new', pin); pg.click('#pin-save'); pg.wait_for_timeout(300)

with sync_playwright() as p:
    b = p.chromium.launch()
    # ---- paging with a big history ----
    big = base_state(3000); pg = page(b, {'mm_state_v2': json.dumps(big)})
    t0 = time.time(); go(pg, 'history'); pg.wait_for_selector('#hist-list .item'); dt = time.time() - t0
    ok('3000 transactions: history opens quickly (%.0f ms)' % (dt * 1000), dt < 1.5)
    ok('only the first 100 rows are drawn', pg.locator('#hist-list .item').count() == 100)
    ok('"show more" announces the remaining 2900', '2900' in pg.inner_text('#hist-more'))
    pg.click('#hist-more'); pg.wait_for_timeout(150); ok('show more adds 100 rows', pg.locator('#hist-list .item').count() == 200)
    pg.select_option('#f-type', 'income'); pg.wait_for_timeout(150); ok('filter with no matches shows empty state', pg.locator('#hist-list .item').count() == 0)
    pg.select_option('#f-type', 'expense'); pg.wait_for_timeout(150); ok('filter change resets paging to 100', pg.locator('#hist-list .item').count() == 100)
    go(pg, 'home'); ok('home total over 3000 tx correct (-3,000.000)', '-3,000.000' in pg.inner_text('.hero .big'))
    # ---- input limits ----
    go(pg, 'accounts'); pg.click('nav .plus'); pg.fill('#s-amt', '99999999999'); pg.click('#s-save'); pg.wait_for_timeout(150)
    ok('absurd amount rejected, sheet stays open', 'غير صحيحة' in pg.inner_text('#toast') and pg.is_visible('#s-save'))
    pg.fill('#s-amt', '5'); pg.fill('#s-note', 'x' * 200); pg.click('#s-save'); pg.wait_for_timeout(150); ok('overlong note rejected', pg.is_visible('#s-save'))
    pg.fill('#s-note', 'ok'); pg.click('#s-save'); pg.wait_for_timeout(200); ok('valid entry accepted afterwards', not pg.is_visible('#s-save'))
    ok('page 1: no errors/network/dialogs', not pg.errs and not pg.reqs and not pg.dlg)

    # ---- PIN throttling + persistence ----
    pg = page(b); setpin(pg); pg.click('#lock-now'); pg.wait_for_timeout(200)
    for i in range(5): pg.fill('#lk', '0000'); pg.wait_for_timeout(450)
    ok('5th wrong attempt shows a wait message', 'حاول بعد' in pg.inner_text('#lk-err'))
    pg.fill('#lk', '1234'); pg.wait_for_timeout(450); ok('correct PIN refused while locked out', pg.is_visible('#lock') and 'حاول بعد' in pg.inner_text('#lk-err'))
    pg.reload(); pg.wait_for_selector('#lk'); pg.fill('#lk', '1234'); pg.wait_for_timeout(450)
    ok('lock-out survives an app restart', pg.is_visible('#lock') and 'حاول بعد' in pg.inner_text('#lk-err'))
    stt = json.loads(pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)")); stt['settings']['lockUntil'] = 1
    pg.evaluate("v => { var o = JSON.parse(window.name||'{}'); o['mm_state_v2'] = v; window.name = JSON.stringify(o); }", json.dumps(stt)); pg.reload(); pg.wait_for_selector('#lk'); pg.fill('#lk', '1234'); pg.wait_for_timeout(450)
    ok('after the wait expires the correct PIN unlocks and resets the counter', not pg.is_visible('#lock') and json.loads(pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)"))['settings']['fails'] == 0)
    # ---- auto-lock ----
    pg.evaluate("window.__realNow=Date.now; window.__off=0; Date.now=function(){return window.__realNow()+window.__off}")
    hide = "Object.defineProperty(document,'hidden',{get:function(){return %s},configurable:true});document.dispatchEvent(new Event('visibilitychange'))"
    pg.evaluate(hide % 'true'); pg.evaluate("window.__off=5000"); pg.evaluate(hide % 'false'); pg.wait_for_timeout(200)
    ok('short trip to the background does not lock', not pg.is_visible('#lock'))
    pg.evaluate(hide % 'true'); pg.evaluate("window.__off=40000"); pg.evaluate(hide % 'false'); pg.wait_for_timeout(200)
    ok('returning after 30s+ locks the app again', pg.is_visible('#lock'))
    ok('page 2: no errors/network/dialogs', not pg.errs and not pg.reqs and not pg.dlg)

    # ---- screenshot protection toggle ----
    pg = page(b, bridge=True); calls = lambda: pg.evaluate('window.__calls')
    ok('screenshots blocked by default at startup', ['secure', True] in calls())
    go(pg, 'settings'); pg.click('#secure-toggle'); pg.wait_for_timeout(150); ok('toggle allows screenshots and persists', ['secure', False] in calls() and json.loads(pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)"))['settings']['secure'] is False)
    pg.reload(); pg.wait_for_selector('.hero'); pg.wait_for_timeout(200); ok('choice survives restart (blocked flag sent as off)', ['secure', False] in calls() and ['secure', True] not in calls())

    # ---- corrupt data recovery ----
    good = base_state(3); good['accounts'][0]['name'] = 'FromSnapshot'
    pg = page(b, {'mm_state_v2': '{"schema":2,"acc', 'mm_snapshot': json.dumps(good)})
    ok('corrupt file: app opens from snapshot and says so', 'استُرجعت' in pg.inner_text('#toast') and '-3.000' in pg.inner_text('.hero .big'))
    ok('corrupt file kept aside and main file repaired', pg.evaluate("(JSON.parse(window.name||'{}')['mm_corrupt']??null)") == '{"schema":2,"acc' and json.loads(pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)"))['accounts'][0]['name'] == 'FromSnapshot')
    pg = page(b, {'mm_state_v2': 'garbage'})
    ok('corrupt file without snapshot: error screen, data untouched', 'Storage error' in pg.inner_text('body') and pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)") == 'garbage')
    pg = page(b, {'mm_initialized': '1'})
    ok('data file missing after initialisation: error screen, nothing written over it', 'Storage error' in pg.inner_text('body') and pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)") is None)
    b.close()
sys.exit(0 if all(res) else 1)
