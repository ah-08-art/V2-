import json, sys
from playwright.sync_api import sync_playwright
URL = 'file:///home/claude/mazoghi-money/app/src/main/assets/www/index.html'
old = {"pin": "4321", "transactions": [
  {"id": 1, "type": "income", "title": "مرتب (مايو)", "amount": 1500.5, "timestamp": "2025-05-01T10:00:00.000Z", "dateStr": "x"},
  {"id": 2, "type": "expense", "title": "بنزين", "amount": 35.25, "timestamp": "2025-05-03T10:00:00.000Z", "dateStr": "x"}]}
MOCK = "(function(){function L(){try{return JSON.parse(window.name||'{}')}catch(e){return {}}}window.NativeStore={get:function(k){var o=L();return k in o?o[k]:null},set:function(k,v){var o=L();o[k]=v;window.name=JSON.stringify(o);return true}};})();"
res = []
def ok(name, cond): res.append((name, bool(cond))); print(('PASS ' if cond else 'FAIL ') + name)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 390, 'height': 800}); pg = ctx.new_page()
    errs, reqs, dlg = [], [], []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('request', lambda r: reqs.append(r.url) if not r.url.startswith('file:') else None)
    pg.on('dialog', lambda d: (dlg.append(d.message), d.accept()))
    pg.add_init_script(MOCK)
    pg.add_init_script("if(!localStorage.getItem('mm_state_v2')&&!localStorage.getItem('myFinanceData')) localStorage.setItem('myFinanceData', %s)" % json.dumps(json.dumps(old)))
    pg.goto(URL); pg.wait_for_timeout(600)
    ok('lock screen shown (legacy PIN migrated)', pg.is_visible('#lock'))
    pg.fill('#lk', '0000'); pg.wait_for_timeout(400); ok('wrong PIN rejected', pg.is_visible('#lock') and 'غير' in pg.inner_text('#lk-err'))
    pg.fill('#lk', '4321'); pg.wait_for_timeout(500); ok('correct legacy PIN unlocks', not pg.is_visible('#lock'))
    ok('migrated balance 1,465.250 د.ل', '1,465.250' in pg.inner_text('.hero .big'))
    # add expense
    pg.click('nav .plus'); pg.fill('#s-amt', '65.250'); pg.fill('#s-note', 'تسوق <b>x</b>'); pg.click('#s-save'); pg.wait_for_timeout(300)
    ok('expense updates balance to 1,400.000', '1,400.000' in pg.inner_text('.hero .big'))
    ok('note is escaped (no injected tag)', pg.locator('#app b').count() == 0 or '<b>' not in pg.inner_html('#app').replace('&lt;b&gt;', ''))
    # new USD account + rate + transfer
    pg.click('nav [data-go=accounts]'); pg.fill('#a-name', 'دولار'); pg.select_option('#a-cur', 'USD'); pg.click('#a-save'); pg.wait_for_timeout(200)
    pg.click('nav [data-go=settings]'); pg.fill('[data-rate=USD]', '4.8'); pg.click('#rates-save'); pg.wait_for_timeout(200)
    pg.click('nav .plus'); pg.click('[data-type=transfer]'); pg.fill('#s-amt', '48'); pg.click('#s-save'); pg.wait_for_timeout(300)
    pg.click('nav [data-go=accounts]'); txt = pg.inner_text('#app')
    ok('transfer: USD account holds 10.00 $', '10.00' in txt and '$' in txt)
    pg.click('nav [data-go=home]'); ok('total unchanged by transfer (1,400.000)', '1,400.000' in pg.inner_text('.hero .big'))
    # history filter + delete
    pg.click('nav [data-go=history]'); pg.select_option('#f-type', 'expense'); pg.wait_for_timeout(200)
    n = pg.locator('.item').count(); ok('history filter shows expenses only', n == 2)
    pg.click('[data-del]'); pg.click('#ask-yes'); pg.wait_for_timeout(200); ok('delete removes one', pg.locator('.item').count() == n - 1)
    # language + dir
    pg.click('nav [data-go=settings]'); pg.click('[data-lang=en]'); pg.wait_for_timeout(200)
    ok('English switches dir to ltr', pg.evaluate("document.documentElement.dir") == 'ltr' and 'Settings' in pg.inner_text('#app'))
    # persistence
    pg.reload(); pg.wait_for_timeout(600); pg.fill('#lk', '4321'); pg.wait_for_timeout(500)
    ok('state + language persist after reload', pg.evaluate("document.documentElement.dir") == 'ltr' and pg.is_visible('.hero'))
    ok('no blocking browser dialogs used (WebView cannot show them)', not dlg)
    ok('no JS errors', not errs); ok('zero network requests (fully offline)', not reqs)
    if errs: print(errs)
    if reqs: print(reqs)
    ok('data lives in the native store', pg.evaluate("(JSON.parse(window.name||'{}')['mm_state_v2']??null)!==null") and pg.evaluate("(JSON.parse(window.name||'{}')['myFinanceData']??null)!==null"))
    ok('original myFinanceData left untouched', json.loads(pg.evaluate("localStorage.getItem('myFinanceData')")) == old)
    pg.screenshot(path='/home/claude/shot_home.png')
    # read error must never be treated as an empty database
    pg2 = b.new_context().new_page(); pg2.add_init_script("window.NativeStore={get:function(){return '__READ_ERROR__'},set:function(){return true}};")
    pg2.goto(URL); pg2.wait_for_timeout(500)
    ok('read error shows message, no fresh state created', 'Storage error' in pg2.inner_text('body') and pg2.evaluate("localStorage.getItem('mm_state_v2')") is None)
    b.close()
sys.exit(0 if all(c for _, c in res) else 1)
