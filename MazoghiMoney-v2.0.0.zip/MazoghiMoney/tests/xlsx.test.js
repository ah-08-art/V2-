const test = require('node:test'), assert = require('node:assert/strict'), fs = require('fs'), { execFileSync } = require('child_process');
const MMX = require('../app/src/main/assets/www/js/xlsx.js');
test('xlsx opens in openpyxl with correct values, types, rtl, unicode and escaping', () => {
  const bytes = MMX.build([
    { name: 'العمليات', rtl: true, widths: [14, 12, 16], rows: [['التاريخ', 'النوع', 'المبلغ'], ['2026-11-18', 'مصروف <x> & "q"', { v: 1234.567, d: 3 }], ['2026-11-19', 'دخل', { v: 10.5, d: 2 }]] },
    { name: 'Bad:/Name?', rows: [['A'], [{ v: 'bold', b: true }], [-5]] }
  ]);
  fs.writeFileSync('/tmp/t.xlsx', bytes);
  const out = execFileSync('python3', ['-c', `
import openpyxl, json
wb = openpyxl.load_workbook('/tmp/t.xlsx')
a = wb.worksheets[0]; b = wb.worksheets[1]
print(json.dumps({'names': wb.sheetnames, 'rtl': a.sheet_view.rightToLeft, 'hdr': a['A1'].value, 'hdr_bold': a['A1'].font.b,
  'text': a['B2'].value, 'num': a['C2'].value, 'fmt': a['C2'].number_format, 'fmt2': a['C3'].number_format, 'num_type': type(a['C3'].value).__name__,
  'neg': b['A3'].value, 'bold2': b['A2'].font.b, 'freeze': a.freeze_panes, 'w': a.column_dimensions['A'].width}, ensure_ascii=False))`]).toString();
  const r = JSON.parse(out);
  assert.deepEqual(r.names, ['العمليات', 'Bad  Name']); assert.equal(r.rtl, true); assert.equal(r.hdr, 'التاريخ'); assert.equal(r.hdr_bold, true);
  assert.equal(r.text, 'مصروف <x> & "q"'); assert.equal(r.num, 1234.567); assert.equal(r.fmt, '#,##0.000'); assert.equal(r.fmt2, '#,##0.00');
  assert.equal(r.num_type, 'float'); assert.equal(r.neg, -5); assert.equal(r.bold2, true); assert.equal(r.freeze, 'A2'); assert.equal(r.w, 14);
});
test('crc32 matches the standard check value', () => assert.equal(MMX.crc32(new TextEncoder().encode('123456789')), 0xCBF43926));
test('a large sheet (5000 rows) builds and loads', () => {
  const rows = [['n', 'v']]; for (let i = 0; i < 5000; i++) rows.push(['row ' + i, { v: i / 7, d: 3 }]);
  fs.writeFileSync('/tmp/big.xlsx', MMX.build([{ name: 'big', rows }]));
  const n = execFileSync('python3', ['-c', "import openpyxl;print(openpyxl.load_workbook('/tmp/big.xlsx').active.max_row)"]).toString().trim();
  assert.equal(n, '5001');
});
