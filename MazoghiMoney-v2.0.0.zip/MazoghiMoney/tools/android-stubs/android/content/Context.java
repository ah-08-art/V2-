package android.content; import java.util.concurrent.Executor; import java.io.File;
public class Context { public static final String PRINT_SERVICE="print", ALARM_SERVICE="alarm", NOTIFICATION_SERVICE="notification";
 public Object getSystemService(String n){return null;} public <T> T getSystemService(Class<T> c){return null;} public Executor getMainExecutor(){return null;}
 public SharedPreferences getSharedPreferences(String n,int m){return null;} public File getFilesDir(){return null;} public int checkSelfPermission(String p){return 0;}
 public ContentResolver getContentResolver(){return null;} public void startActivityForResult(Intent i,int r){} public void requestPermissions(String[] p,int r){} public void runOnUiThread(Runnable r){} }