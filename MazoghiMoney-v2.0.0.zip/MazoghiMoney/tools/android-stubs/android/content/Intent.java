package android.content; import android.net.Uri;
public class Intent { public static final String ACTION_CREATE_DOCUMENT="a",ACTION_OPEN_DOCUMENT="b",CATEGORY_OPENABLE="c",EXTRA_TITLE="d",ACTION_BOOT_COMPLETED="e";
 public Intent(){} public Intent(String a){} public Intent(Context c,Class<?> k){} public Intent addCategory(String c){return this;} public Intent setType(String t){return this;}
 public Intent putExtra(String k,String v){return this;} public String getStringExtra(String k){return null;} public Uri getData(){return null;} public String getAction(){return null;} }