@echo off
rem Windows: builds a debug APK and copies it to MazoghiMoney-debug.apk
cd /d "%~dp0.."
if "%ANDROID_HOME%"=="" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platforms" (
  echo Android SDK not found at %ANDROID_HOME%.
  echo Install Android Studio ^(it includes the SDK^) or set ANDROID_HOME, then run this again.
  exit /b 1
)
echo sdk.dir=%ANDROID_HOME:\=\\%> local.properties
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle not found. Install Gradle 8.5+ or open this folder in Android Studio and use Build ^> Build APK^(s^).
  exit /b 1
)
call gradle assembleDebug || exit /b 1
copy /Y app\build\outputs\apk\debug\app-debug.apk MazoghiMoney-debug.apk
echo APK ready: %CD%\MazoghiMoney-debug.apk
