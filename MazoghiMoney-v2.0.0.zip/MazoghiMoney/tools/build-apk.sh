#!/bin/sh
# Linux / macOS: builds a debug APK and copies it to ./MazoghiMoney-debug.apk
set -e
cd "$(dirname "$0")/.."
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
[ -d "$SDK/platforms" ] || { echo "Android SDK not found at $SDK."; echo "Install Android Studio (it includes the SDK) or set ANDROID_HOME, then run this again."; exit 1; }
echo "sdk.dir=$SDK" > local.properties
if [ -x ./gradlew ]; then G=./gradlew; elif command -v gradle >/dev/null 2>&1; then G=gradle
else echo "Gradle not found. Install Gradle 8.5+ (or just open the folder in Android Studio and use Build > Build APK(s))."; exit 1; fi
"$G" assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk MazoghiMoney-debug.apk
echo "APK ready: $(pwd)/MazoghiMoney-debug.apk"
