#!/bin/sh
# Compiles the app's Java against minimal Android stubs (no SDK needed). Verifies types, lambdas and exception handling of our own code;
# it does NOT prove that the Android APIs exist on a device - build with Android Studio for that.
cd "$(dirname "$0")/../app/src/main/java" || exit 1
rm -rf /tmp/mm-jout
java -m jdk.compiler/com.sun.tools.javac.Main -proc:none -d /tmp/mm-jout $(find ../../../../tools/android-stubs -name '*.java') $(find . -name '*.java') && echo "Java OK"
