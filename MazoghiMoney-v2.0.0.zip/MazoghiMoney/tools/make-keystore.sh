#!/bin/sh
# Creates the release keystore and keystore.properties. Keep BOTH the .jks file and its passwords safe:
# losing them means you can never publish an update that installs over the existing app.
set -e
cd "$(dirname "$0")/.."
[ -f mazoghi-release.jks ] && { echo "mazoghi-release.jks already exists - refusing to overwrite"; exit 1; }
if [ -z "$MM_STORE_PASS" ]; then printf "Keystore password (min 6 chars): "; stty -echo; read MM_STORE_PASS; stty echo; echo; fi
[ ${#MM_STORE_PASS} -ge 6 ] || { echo "password too short"; exit 1; }
keytool -genkeypair -keystore mazoghi-release.jks -alias mazoghi -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$MM_STORE_PASS" -keypass "$MM_STORE_PASS" -dname "${MM_DNAME:-CN=Mazoghi Money, O=Mazoghi, C=LY}"
printf "storeFile=mazoghi-release.jks\nstorePassword=%s\nkeyAlias=mazoghi\nkeyPassword=%s\n" "$MM_STORE_PASS" "$MM_STORE_PASS" > keystore.properties
chmod 600 keystore.properties mazoghi-release.jks
echo "Done. Build the signed release with:  gradle assembleRelease"
